//
//  HomeBannerModel.m
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "HomeBannerModel.h"

@implementation HomeBannerModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

- (id)valueForUndefinedKey:(NSString *)key {
    return nil;
}

- (instancetype)initWithDic:(NSDictionary *)dic {
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dic];
    }
    return self;
}

+ (HomeBannerModel *)homeBannerModelWithDic:(NSDictionary *)dic {
    HomeBannerModel *model = [[HomeBannerModel alloc] initWithDic:dic];
    return model;
}

@end
