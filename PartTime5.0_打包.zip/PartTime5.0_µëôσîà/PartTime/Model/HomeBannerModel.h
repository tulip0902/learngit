//
//  HomeBannerModel.h
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HomeBannerModel : NSObject

@property (nonatomic, strong) NSString *photoInfoUrl;
@property (nonatomic, strong) NSString *photoUrl;
@property (nonatomic, strong) NSString *title;

- (instancetype)initWithDic:(NSDictionary *)dic;

+ (HomeBannerModel *)homeBannerModelWithDic:(NSDictionary *)dic;

@end
