//
//  HomeADModel.h
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HomeADModel : NSObject

@property (nonatomic, strong) NSNumber *cityId;
@property (nonatomic, strong) NSString *clickUrl;
@property (nonatomic, strong) NSNumber *creatTime;
@property (nonatomic, strong) NSNumber *myId;//id
@property (nonatomic, strong) NSNumber *isDel;
@property (nonatomic, strong) NSNumber *jobId;
@property (nonatomic, strong) NSNumber *modifTime;
@property (nonatomic, strong) NSString *photoUrl;
@property (nonatomic, strong) NSNumber *sort;
@property (nonatomic, strong) NSString *title1;
@property (nonatomic, strong) NSString *title2;

- (instancetype)initWithDic:(NSDictionary *)dic;

+ (HomeADModel *)homeADModelWithDic:(NSDictionary *)dic;

@end
