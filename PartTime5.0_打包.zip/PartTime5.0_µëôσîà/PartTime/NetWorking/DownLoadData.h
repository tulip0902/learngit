
#import <Foundation/Foundation.h>

@interface DownLoadData : NSObject

//=========================================================
//首页中滚动视图接口
//http://www.1mjz.com/v1/api/stu/banner/list?position=0
+ (NSURLSessionDataTask *)getHomeBannerData:(void (^) (id obj, NSError *error))block;

//首页中推荐职位接口
//http://www.1mjz.com/v1/api/stu/job/ad/list?cityId=34
+ (NSURLSessionDataTask *)getHomeADData:(void (^) (id obj, NSError *error))block;

//首页中最新职位接口
//http://www.1mjz.com/v1/api/stu/job/home/list?cityId=34&lat=40.037642&lon=116.370025
+ (NSURLSessionDataTask *)getHomeLatestData:(void (^) (id obj, NSError *error))block withLat:(NSNumber *)lat withLon:(NSNumber *)lon;

//首页中最新职位详情接口
//http://www.1mjz.com/v1/api/stu/job/detail?jobId=88149&stuId=0
+ (NSURLSessionDataTask *)getHomeLatestDetailsData:(void (^) (id obj, NSError *error))block withJobId:(NSNumber *)jobId;

//公司简介接口
//http://www.1mjz.com/v1/api/stu/corp/item?corpId=79984
+ (NSURLSessionDataTask *)getCorpData:(void (^) (id obj, NSError *error))block withCorpId:(NSNumber *)corpId;

//公司简介中的商家职位接口
//http://www.1mjz.com/v1/api/stu/corp/job/list?corpId=79984
+ (NSURLSessionDataTask *)getCorpJobData:(void (^) (id obj, NSError *error))block withCorpId:(NSNumber *)corpId;

//=========================================================
//兼职页面接口
//http://www.1mjz.com/v1/api/stu/job/list?cityId=34&jobTypeId=0&km=0&lat=40.037628&lon=116.369954&pageNum=1&pageSize=10&sort=0
+ (NSURLSessionDataTask *)getPartTimeJobData:(void (^) (id obj, NSError *error))block withPageNum:(NSInteger)pageNum withJobTypeId:(NSInteger)jobTypeId withDistance:(NSInteger)distance withSort:(NSInteger)sort withLat:(NSNumber *)lat withLon:(NSNumber *)lon;

//==========================================================
//保送页面接口
//http://www.1mjz.com/v1/api/stu/express/job/list?cityId=34&lat=40.037584&lon=116.36987&pageNum=1&pageSize=5
+ (NSURLSessionDataTask *)getSendJobData:(void (^) (id obj, NSError *error))block withPageNum:(NSNumber *)pageNum withLat:(NSNumber *)lat withLon:(NSNumber *)lon;

//保送页面详情接口
//http://www.1mjz.com/v1/api/stu/express/job/detail?jobId=101505
+ (NSURLSessionDataTask *)getSendJobDetailsData:(void (^) (id obj, NSError *error))block withJobId:(NSNumber *)jobId;

@end















