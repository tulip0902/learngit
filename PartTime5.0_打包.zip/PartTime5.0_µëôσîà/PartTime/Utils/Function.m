//
//  Function.m
//  PartTime
//
//  Created by tulip on 15-9-20.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "Function.h"

@implementation Function

+ (NSString *)getPriceWithPay:(NSNumber *)pay andPayUnit:(NSNumber *)payUnit {
    NSInteger unit = [payUnit integerValue];
    NSString *priceStr;
    if (unit == 1) {
        priceStr = [NSString stringWithFormat:@"%@元/小时", pay];
    }else if(unit == 2) {
        priceStr = [NSString stringWithFormat:@"%@元/天", pay];
    }else if(unit == 3) {
        priceStr = [NSString stringWithFormat:@"%@元/月", pay];
    }else {
        priceStr = [NSString stringWithFormat:@"%@元/件", pay];
    }
    return priceStr;
}

+ (NSString *)getSettleTypeWithId:(NSNumber *)jobsettletypeId {
    NSArray *settleTypeArr = @[@"日结", @"周结", @"月结", @"完结"];
    NSInteger settleType = [jobsettletypeId integerValue];
    if (settleType > 0 & settleType < 5) {
        return settleTypeArr[settleType - 1];
    }
    return nil;
}

//根据性别，学历，年龄，身高，返回一个字符串
+ (NSString *)getRequestWithSex:(int)sex andGrade:(int)grade andMinAge:(int)minAge andMaxAge:(int)maxAge andHeight:(float)height {
    NSString *sexStr;
    if (sex == 0) {
        sexStr = @"性别不限";
    }else if (sex == 1) {
        sexStr = @"性别男";
    }else{
        sexStr = @"性别女";
    }
    
    NSString *gradeStr;
    if (grade == 0) {
        gradeStr = @"学历不限";
    }else if(grade == 1){
        gradeStr = @"学历高中";
    }else if(grade == 2){
        gradeStr = @"学历专科";
    }else if (grade == 3) {
        gradeStr = @"学历本科";
    }else{
        gradeStr = @"学历不限";
    }
    
    NSString *age;
    if (minAge == 0 & maxAge == 0) {
        age = @"年龄不限";
    }else if (minAge > 0 & maxAge == 0){
        age = [NSString stringWithFormat:@"年龄%d+", minAge];
    }else{
        age = [NSString stringWithFormat:@"年龄%d-%d", minAge, maxAge];
    }
    
    NSString *heightStr;
    if (height == 0) {
        heightStr = @"身高不限";
    }else{
        heightStr = [NSString stringWithFormat:@"身高%dcm", (int)height];
    }
    return [NSString stringWithFormat:@"%@/%@/%@/%@", sexStr, gradeStr, age, heightStr];
}

@end
