//
//  SendDetailsTableViewCell.m
//  PartTime
//
//  Created by MS on 15-9-22.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "SendDetailsTableViewCell.h"

@interface SendDetailsTableViewCell ()

@property (nonatomic, strong) UILabel *titleLabel;

@property (nonatomic, strong) KeyAndValueView *priceView;
@property (nonatomic, strong) KeyAndValueView *countView;
@property (nonatomic, strong) KeyAndValueView *endView;
@property (nonatomic, strong) KeyAndValueView *dateView;
@property (nonatomic, strong) KeyAndValueView *timeView;
@property (nonatomic, strong) KeyAndValueView *addressView;
@property (nonatomic, strong) LimitView *limitView;

@end

@implementation SendDetailsTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        CGFloat startX = 10;
        CGFloat startY = 10;
        CGFloat eachHeight = 30;
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(startX, startY, SCREEN_WIDTH - 2 * startX, eachHeight)];
        [self.contentView addSubview:titleLabel];
        self.titleLabel = titleLabel;
        startY += eachHeight;
        
        KeyAndValueView *priceView = [[KeyAndValueView alloc] initWithFrame:CGRectMake(startX, startY, SCREEN_WIDTH - 2 * startX, eachHeight)];
        [self.contentView addSubview:priceView];
        self.priceView = priceView;
        startY += eachHeight;
        
        KeyAndValueView *countView = [[KeyAndValueView alloc] initWithFrame:CGRectMake(startX, startY, SCREEN_WIDTH - 2 * startX, eachHeight)];
        [self.contentView addSubview:countView];
        self.countView = countView;
        startY += eachHeight;
        
        KeyAndValueView *endView = [[KeyAndValueView alloc] initWithFrame:CGRectMake(startX, startY, SCREEN_WIDTH - 2 * startX, eachHeight)];
        [self.contentView addSubview:endView];
        self.endView = endView;
        startY += eachHeight;
        
        KeyAndValueView *dateView = [[KeyAndValueView alloc] initWithFrame:CGRectMake(startX, startY, SCREEN_WIDTH - 2 * startX, eachHeight)];
        [self.contentView addSubview:dateView];
        self.dateView = dateView;
        startY += eachHeight;
        
        KeyAndValueView *timeView = [[KeyAndValueView alloc] initWithFrame:CGRectMake(startX, startY, SCREEN_WIDTH - 2 * startX, eachHeight)];
        [self.contentView addSubview:timeView];
        self.timeView = timeView;
        startY += eachHeight;
        
        KeyAndValueView *addressView = [[KeyAndValueView alloc] initWithFrame:CGRectMake(startX, startY, SCREEN_WIDTH - 2 * startX, eachHeight)];
        [self.contentView addSubview:addressView];
        self.addressView = addressView;
        startY += eachHeight;
        
        LimitView *limitView = [[LimitView alloc] initWithFrame:CGRectMake(startX, startY, SCREEN_WIDTH - 2 * startX, 20)];
        [self.contentView addSubview:limitView];
        self.limitView = limitView;
        startY += 20;
        
        self.frame = CGRectMake(0, 0, SCREEN_WIDTH, startY + 10);
    }
    return self;
}

- (void)updateInfoWithDataDic:(NSDictionary *)dataDic {
    self.titleLabel.text = [dataDic objectForKey:@"jobName"];
    
    self.priceView.keyLabel.text = @"薪资待遇:";
    self.priceView.valueLabel.text = [Function getPriceWithPay:dataDic[@"postMoney"] andPayUnit:dataDic[@"payunit"]];
    
    self.countView.keyLabel.text = @"剩余人数:";
    self.countView.valueLabel.text = [NSString stringWithFormat:@"%@人", dataDic[@"oddNum"]];
    
    self.endView.keyLabel.text = @"报名截止:";
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm"];
    NSString *timeStr = [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:[dataDic[@"regiEndTime"] longLongValue]]];
    self.endView.valueLabel.text = timeStr;
    
    self.dateView.keyLabel.text = @"工作日期:";
    [formatter setDateFormat:@"MM月dd日"];
    timeStr = [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:[dataDic[@"jobDate"] longLongValue]]];
    self.dateView.valueLabel.text = timeStr;
    [formatter setDateFormat:@"HH:mm"];
    
    self.timeView.keyLabel.text = @"工作时间:";
    NSString *startTimeStr = [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:[dataDic[@"jobStartHM"] longLongValue]]];
    NSString *endTimeStr = [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:[dataDic[@"jobEndHM"] longLongValue]]];
    self.timeView.valueLabel.text = [NSString stringWithFormat:@"%@ - %@", startTimeStr, endTimeStr];
    
    self.addressView.keyLabel.text = @"工作地点:";
    self.addressView.valueLabel.text = dataDic[@"address"];
    
    self.frame = [self getCellFrame];
    
}

//设置cell高度自适应
- (CGRect)getCellFrame {
    CGRect frame = self.frame;
    
    CGSize size = CGSizeMake(self.addressView.valueLabel.frame.size.width, 1000);
    CGRect detailSize = [self.addressView.valueLabel.text boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName :self.addressView.valueLabel.font} context:nil];
    
//    重新设置frame
    self.addressView.frame = CGRectMake(self.addressView.frame.origin.x, self.addressView.frame.origin.y, self.addressView.frame.size.width, detailSize.size.height);
    
    self.limitView.frame = CGRectMake(self.limitView.frame.origin.x, self.addressView.frame.origin.y + self.addressView.frame.size.height + 5, self.limitView.frame.size.width, self.limitView.frame.size.height);
    
    frame.size.height = self.limitView.frame.origin.y + self.limitView.frame.size.height + 10;
    
    return frame;
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
