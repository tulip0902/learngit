//
//  KeyAndValueView.m
//  PartTime
//
//  Created by MS on 15-9-22.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "KeyAndValueView.h"

@implementation KeyAndValueView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.keyLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 80, frame.size.height)];
        [self addSubview:self.keyLabel];
        
        self.valueLabel = [[UILabel alloc] initWithFrame:CGRectMake(80, 0, frame.size.width-80, frame.size.height)];
        self.valueLabel.numberOfLines = 20;
        [self addSubview:self.valueLabel];
    }
    return self;
}

- (void)setFrame:(CGRect)frame {
    [super setFrame:frame];
    
    self.keyLabel.frame = CGRectMake(self.keyLabel.frame.origin.x, self.keyLabel.frame.origin.y, self.keyLabel.frame.size.width, frame.size.height);
    
    self.valueLabel.frame = CGRectMake(self.valueLabel.frame.origin.x, self.valueLabel.frame.origin.y, self.valueLabel.frame.size.width, frame.size.height);
    
    
}

- (void)setContentFont:(UIFont *)contentFont {
    //        设置字体
    self.keyLabel.font = contentFont;
    self.valueLabel.font = contentFont;
}

@end
