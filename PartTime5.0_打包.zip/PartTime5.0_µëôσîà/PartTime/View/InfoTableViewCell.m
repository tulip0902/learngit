//
//  InfoTableViewCell.m
//  PartTime
//
//  Created by tulip on 15-9-20.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "InfoTableViewCell.h"

@interface InfoTableViewCell ()

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) KeyAndValueView *priceView;
@property (nonatomic, strong) KeyAndValueView *countView;
@property (nonatomic, strong) KeyAndValueView *timeView;
@property (nonatomic, strong) KeyAndValueView *addressView;
@property (nonatomic, strong) KeyAndValueView *requestView;

@end

@implementation InfoTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        UIView *superView = self.contentView;
        
//        CGFloat padding = 5;
//        CGFloat leftLabelWidth = 70;
        
        CGFloat startX = 5;
        CGFloat startY = 5;
        CGFloat eachWidth = SCREEN_WIDTH - 2 * startX;
        CGFloat eachHeight = 30;
        
        UIFont *myFont = [UIFont systemFontOfSize:14];
        
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(startX, startY, eachWidth, eachHeight)];
        [superView addSubview:titleLabel];
        self.titleLabel = titleLabel;
        startY += eachHeight;
        
        KeyAndValueView *priceView = [[KeyAndValueView alloc] initWithFrame:CGRectMake(startX, startY, eachWidth, eachHeight)];
        priceView.contentFont = myFont;
        [superView addSubview:priceView];
        self.priceView = priceView;
        startY += eachHeight;
        
        KeyAndValueView *countView = [[KeyAndValueView alloc] initWithFrame:CGRectMake(startX, startY, eachWidth, eachHeight)];
        countView.contentFont = myFont;
        [superView addSubview:countView];
        self.countView = countView;
        startY += eachHeight;
        
        KeyAndValueView *timeView = [[KeyAndValueView alloc] initWithFrame:CGRectMake(startX, startY, eachWidth, eachHeight)];
        timeView.contentFont = myFont;
        [superView addSubview:timeView];
        self.timeView = timeView;
        startY += eachHeight;
        
        KeyAndValueView *addressView = [[KeyAndValueView alloc] initWithFrame:CGRectMake(startX, startY, eachWidth, eachHeight)];
        addressView.contentFont = myFont;
        [superView addSubview:addressView];
        self.addressView = addressView;
        startY += eachHeight;
        
        KeyAndValueView *requestView = [[KeyAndValueView alloc] initWithFrame:CGRectMake(startX, startY, eachWidth, eachHeight)];
        requestView.contentFont = myFont;
        [superView addSubview:requestView];
        self.requestView = requestView;
        startY += eachHeight;
        
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, startY + 5);
    }
    return self;
}

- (void)updateInfoWithDataDic:(NSDictionary *)dataDic {
//    标题
    self.titleLabel.text = [dataDic objectForKey:@"name"];
    //        工资待遇
    NSString *price = [Function getPriceWithPay:[dataDic objectForKey:@"pay"] andPayUnit:[dataDic objectForKey:@"payUnit"]];
    NSString *settle = [Function getSettleTypeWithId:[dataDic objectForKey:@"jobsettletypeId"]];
    self.priceView.keyLabel.text = @"工资待遇:";
    self.priceView.valueLabel.text = [NSString stringWithFormat:@"%@  [%@]", price, settle];
    //        剩余人数
    self.countView.keyLabel.text = @"剩余人数:";
    self.countView.valueLabel.text = [NSString stringWithFormat:@"%@人", [dataDic objectForKey:@"count"]];
    //        有效时间
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    NSNumber *startTime = [dataDic objectForKey:@"startTime"];
    NSString *startTimeStr = [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:[startTime longLongValue]]];
    NSNumber *endTime = [dataDic objectForKey:@"endTime"];
    NSString *endTimeStr = [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:[endTime longLongValue]]];
    self.timeView.keyLabel.text = @"有效时间:";
    self.timeView.valueLabel.text = [NSString stringWithFormat:@"%@ - %@", startTimeStr, endTimeStr];
    //        工作地点
    self.addressView.keyLabel.text = @"工作地点:";
    self.addressView.valueLabel.text = [dataDic objectForKey:@"address"];
    //        招聘条件
    int sex = [[dataDic objectForKey:@"sex"] intValue];
    int grade = [[dataDic objectForKey:@"grade"] intValue];
    int minAge = [[dataDic objectForKey:@"minage"] intValue];
    int maxAge = [[dataDic objectForKey:@"maxage"] intValue];
    float height = [[dataDic objectForKey:@"height"] floatValue];
    self.requestView.keyLabel.text = @"招聘条件:";
    self.requestView.valueLabel.text = [Function getRequestWithSex:sex andGrade:grade andMinAge:minAge andMaxAge:maxAge andHeight:height];
    
    self.frame = [self getCellFrame];
}

//设置cell高度自适应
- (CGRect)getCellFrame {
    CGRect frame = self.frame;
    
    CGFloat startY = self.addressView.frame.origin.y;
    
    CGSize size = CGSizeMake(self.addressView.valueLabel.frame.size.width, 1000);
    CGRect detailSize = [self.addressView.valueLabel.text boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName :self.addressView.valueLabel.font} context:nil];
    
//    重新设置label的frame
    self.addressView.frame = CGRectMake(self.addressView.frame.origin.x, startY, detailSize.size.width, detailSize.size.height);
    startY += detailSize.size.height + 10;
    
    detailSize = [self.requestView.valueLabel.text boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName :self.requestView.valueLabel.font} context:nil];
    
    //    重新设置label的frame
    self.requestView.frame = CGRectMake(self.requestView.frame.origin.x, startY, detailSize.size.width, detailSize.size.height);
    startY += detailSize.size.height + 10;
    
    frame.size.height = startY + 5;
    
    return frame;
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
