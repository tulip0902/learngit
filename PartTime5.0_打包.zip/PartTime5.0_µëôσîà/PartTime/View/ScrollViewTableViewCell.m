//
//  ScrollViewTableViewCell.m
//  EnjoyTravels
//
//  Created by tulip on 15-9-4.
//  Copyright (c) 2015年 李海涛. All rights reserved.
//

#import "ScrollViewTableViewCell.h"

#define SCROLL_HEIGHT 150

@interface ScrollViewTableViewCell()<UIScrollViewDelegate>



@end

@implementation ScrollViewTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {

        //    初始化scrollView
        self.scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCROLL_HEIGHT)];
        self.scrollView.delegate = self;
        
        self.scrollView.pagingEnabled = YES;
        self.scrollView.bounces = NO;
        self.scrollView.showsHorizontalScrollIndicator = NO;
        self.scrollView.showsVerticalScrollIndicator = NO;
        [self.contentView addSubview:self.scrollView];
        
        //    初始化pageControl
        self.pageControl = [[UIPageControl alloc] init];
        self.pageControl.backgroundColor = [UIColor colorWithWhite:0.000 alpha:0.370];
        [self.pageControl addTarget:self action:@selector(pageChanged:) forControlEvents:UIControlEventValueChanged];
        [self.contentView addSubview:self.pageControl];
        
        [self.pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView.mas_left).offset(0);
            make.right.equalTo(self.contentView.mas_right).offset(0);
            make.bottom.equalTo(self.scrollView.mas_bottom).offset(0);
            make.height.equalTo(@30);
        }];
    }
    return self;
}

- (void)showImagesAtScrollView:(NSArray *)imagePathArr {
    [self.scrollView subviews];
    
    [imagePathArr enumerateObjectsUsingBlock:^(NSString *obj, NSUInteger idx, BOOL *stop) {
        NSString *imagePath = [NSString stringWithFormat:@"http://www.1mjz.com%@", obj];
        NSURL *imageUrl = [NSURL URLWithString:imagePath];
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH * idx, 0, SCREEN_WIDTH, SCROLL_HEIGHT)];
        [imageView setImageWithURL:imageUrl placeholderImage:[UIImage imageNamed:@"home_special_default"]];
        [self.scrollView addSubview:imageView];
    }];
    self.scrollView.contentSize = CGSizeMake(SCREEN_WIDTH * imagePathArr.count, SCROLL_HEIGHT);
    
    self.pageControl.numberOfPages = imagePathArr.count;
    
}

- (void)changePage {
//    NSLog(@"numbers = %ld", self.pageControl.numberOfPages);
}

- (void)pageChanged:(id)sender {
//    获取当前页
    NSInteger pageIndex = self.pageControl.currentPage;
    self.scrollView.contentOffset = CGPointMake(pageIndex * self.contentView.frame.size.width, 0);
    
}

#pragma mark --实现协议UIScrollViewDelegate中的方法
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    NSInteger page = scrollView.contentOffset.x/self.contentView.frame.size.width;
    self.pageControl.currentPage = page;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
