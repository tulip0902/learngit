//
//  ScrollViewTableViewCell.h
//  EnjoyTravels
//
//  Created by tulip on 15-9-4.
//  Copyright (c) 2015年 李海涛. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScrollViewTableViewCell : UITableViewCell

@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIPageControl *pageControl;

- (void)showImagesAtScrollView:(NSArray *)imagePathArr;

@end
