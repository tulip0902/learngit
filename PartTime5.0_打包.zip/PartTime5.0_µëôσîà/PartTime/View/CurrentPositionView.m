//
//  CurrentPositionView.m
//  PartTime
//
//  Created by tulip on 15-9-27.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "CurrentPositionView.h"

@implementation CurrentPositionView

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {
        self.currentPosition = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width - self.frame.size.height, self.frame.size.height)];
        [self addSubview:self.currentPosition];
        
        self.refreshBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        self.refreshBtn.frame = CGRectMake(self.frame.size.width - self.frame.size.height, 0, self.frame.size.height, self.frame.size.height);
        [self.refreshBtn setImage:[UIImage imageNamed:@"refresh"] forState:UIControlStateNormal];
        self.refreshBtn.layer.cornerRadius = 8;
        self.refreshBtn.layer.masksToBounds = YES;
        [self addSubview:self.refreshBtn];
    }
    return self;
}

@end
