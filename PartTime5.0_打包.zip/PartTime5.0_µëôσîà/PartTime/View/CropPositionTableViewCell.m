//
//  CropPositionTableViewCell.m
//  PartTime
//
//  Created by MS on 15-9-23.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "CropPositionTableViewCell.h"

@interface CropPositionTableViewCell ()

@property (nonatomic, strong) UILabel *jobContent;
@property (nonatomic, strong) UILabel *price;
@property (nonatomic, strong) UILabel *settleType;

@end

@implementation CropPositionTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UIView *superView = self.contentView;
        
        UILabel *jobContent = [[UILabel alloc] init];
        [superView addSubview:jobContent];
        self.jobContent = jobContent;
        self.jobContent.textColor = [UIColor blueColor];
        
        UILabel *price = [[UILabel alloc] init];
        [superView addSubview:price];
        self.price = price;
        self.price.textColor = [UIColor colorWithRed:0.840 green:0.558 blue:0.278 alpha:1.000];
        
        UILabel *settleType = [[UILabel alloc] init];
        [superView addSubview:settleType];
        self.settleType = settleType;
        self.settleType.textAlignment = NSTextAlignmentCenter;
        self.settleType.layer.cornerRadius = 6;
        self.settleType.layer.masksToBounds = YES;
        self.settleType.backgroundColor = [UIColor purpleColor];
        self.settleType.textColor = [UIColor whiteColor];
        self.settleType.font = [UIFont systemFontOfSize:14];
        
        [jobContent mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(superView.mas_left).offset(10);
            make.top.equalTo(superView.mas_top).offset(5);
            make.right.equalTo(superView.mas_right).offset(-5);
            make.bottom.equalTo(price.mas_top).offset(-5);
            make.height.equalTo(@[price]);
        }];
        
        [self.price mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView.mas_left).offset(10);
            make.right.equalTo(self.settleType.mas_left).offset(-5);
            make.bottom.equalTo(self.contentView.mas_bottom).offset(-5);
        }];
        
        [settleType mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(superView.mas_right).offset(-10);
            make.bottom.equalTo(superView.mas_bottom).offset(-5);
            make.width.equalTo(@40);
        }];
        
    }
    return self;
}

- (void)updateInfoWithModel:(HomeLatestModel *)model {
    
    self.jobContent.text = model.name;
    
    self.price.text = [Function getPriceWithPay:model.pay andPayUnit:model.payUnit];
    
    self.settleType.text = [Function getSettleTypeWithId:model.jobsettletypeId];
    NSArray *colorArr = @[[UIColor colorWithRed:0.897 green:0.062 blue:0.324 alpha:1.000], [UIColor colorWithRed:0.637 green:0.445 blue:0.957 alpha:1.000], [UIColor colorWithRed:0.903 green:0.466 blue:0.202 alpha:1.000], [UIColor colorWithRed:0.000 green:0.696 blue:0.000 alpha:1.000]];
    NSInteger settleType = [model.jobsettletypeId integerValue];
    self.settleType.backgroundColor = colorArr[settleType - 1];
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
