//
//  CorpInfoTableViewCell.h
//  PartTime
//
//  Created by MS on 15-9-23.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CorpInfoTableViewCell : UITableViewCell

- (void)updateInfoWithDataDic:(NSDictionary *)dataDic;

@end
