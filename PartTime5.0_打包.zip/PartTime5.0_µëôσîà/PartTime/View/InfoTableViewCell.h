//
//  InfoTableViewCell.h
//  PartTime
//
//  Created by tulip on 15-9-20.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfoTableViewCell : UITableViewCell

- (void)updateInfoWithDataDic:(NSDictionary *)dataDic;

@end
