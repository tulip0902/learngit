//
//  CorpInfoTableViewCell.m
//  PartTime
//
//  Created by MS on 15-9-23.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "CorpInfoTableViewCell.h"

@interface CorpInfoTableViewCell ()

@property (nonatomic, strong) KeyAndValueView *corpNameView;
@property (nonatomic, strong) KeyAndValueView *corpTypeView;
@property (nonatomic, strong) KeyAndValueView *countView;
@property (nonatomic, strong) KeyAndValueView *addressView;

@end

@implementation CorpInfoTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        CGFloat startX = 10;
        CGFloat startY = 10;
        CGFloat eachHeight = 30;
        
        KeyAndValueView *corpNameView = [[KeyAndValueView alloc] initWithFrame:CGRectMake(startX, startY, SCREEN_WIDTH - 2 * startX, eachHeight)];
        [self.contentView addSubview:corpNameView];
        self.corpNameView = corpNameView;
        startY += eachHeight;
        
        KeyAndValueView *corpTypeView = [[KeyAndValueView alloc] initWithFrame:CGRectMake(startX, startY, SCREEN_WIDTH - 2 * startX, eachHeight)];
        [self.contentView addSubview:corpTypeView];
        self.corpTypeView = corpTypeView;
        startY += eachHeight;

        KeyAndValueView *countView = [[KeyAndValueView alloc] initWithFrame:CGRectMake(startX, startY, SCREEN_WIDTH - 2 * startX, eachHeight)];
        [self.contentView addSubview:countView];
        self.countView = countView;
        startY += eachHeight;
        
        KeyAndValueView *addressView = [[KeyAndValueView alloc] initWithFrame:CGRectMake(startX, startY, SCREEN_WIDTH - 2 * startX, eachHeight)];
        [self.contentView addSubview:addressView];
        self.addressView = addressView;
        startY += eachHeight;
        
        self.frame = CGRectMake(0, 0, SCREEN_WIDTH, startY + 10);
    }
    return self;
}

- (void)updateInfoWithDataDic:(NSDictionary *)dataDic {
    
    self.corpNameView.keyLabel.text = @"商家全称:";
    self.corpNameView.valueLabel.text = dataDic[@"name"];
    
    self.corpTypeView.keyLabel.text = @"商家属性:";
    self.corpTypeView.valueLabel.text = [self getCorpTypeWithPropertyId:dataDic[@"propertyId"]];
    
    self.countView.keyLabel.text = @"员工人数:";
    self.countView.valueLabel.text = [self getCountWithSizeId:dataDic[@"sizeId"]];
    
    self.addressView.keyLabel.text = @"商家地址:";
    self.addressView.valueLabel.text = dataDic[@"address"];
    
}

- (NSString *)getCountWithSizeId:(NSNumber *)sizeId {
    int count = [sizeId intValue];
    if (count == 1) {
        return @"0至20人";
    }else if(count == 2) {
        return @"21至50人";
    }else{
        return @"51至200人";
    }
}


- (NSString *)getCorpTypeWithPropertyId:(NSNumber *)propertyId {
    int property = [propertyId intValue];
    if (property == 1) {
        return @"国营企业";
    }else if(property == 2) {
        return @"民营企业";
    }else{
        return @"未知";
    }
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
