//
//  KeyAndValueView.h
//  PartTime
//
//  Created by MS on 15-9-22.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KeyAndValueView : UIView

@property (nonatomic, strong) UILabel *keyLabel;
@property (nonatomic, strong) UILabel *valueLabel;

@property (nonatomic, strong) UIFont *contentFont;

- (void)setContentFont:(UIFont *)contentFont;//设置label上内容的大小

@end
