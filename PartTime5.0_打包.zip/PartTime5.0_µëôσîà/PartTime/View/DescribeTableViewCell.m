//
//  DescribeTableViewCell.m
//  PartTime
//
//  Created by tulip on 15-9-20.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "DescribeTableViewCell.h"

@interface DescribeTableViewCell ()

@property (nonatomic, strong) UILabel *contentLabel;

@end

@implementation DescribeTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UILabel *contentLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 5, SCREEN_WIDTH - 10, 90)];
        contentLabel.numberOfLines = 0;
        contentLabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:contentLabel];
        self.contentLabel = contentLabel;
        
    }
    return self;
}

- (void)updateWithContent:(NSString *)content {
    self.contentLabel.text = content;
    
    self.frame = [self getCellFrame];
}

//设置cell高度自适应
- (CGRect)getCellFrame {
    CGRect frame = self.frame;
    
    CGSize size = CGSizeMake(SCREEN_WIDTH-10, 1000);
    CGRect detailSize = [self.contentLabel.text boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName :self.contentLabel.font} context:nil];
    //    重新设置label的frame
    self.contentLabel.frame = CGRectMake(self.contentLabel.frame.origin.x, self.contentLabel.frame.origin.y, detailSize.size.width, detailSize.size.height);
    
    frame.size.height = detailSize.size.height + 10;
    
    return frame;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
