//
//  LimitView.m
//  PartTime
//
//  Created by MS on 15-9-22.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "LimitView.h"

@implementation LimitView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        CGFloat width = 60;
        CGFloat height = self.frame.size.height;
        CGFloat startX = 0;
        
        UIFont *myFont = [UIFont systemFontOfSize:12];
        
        UIImageView *heightImageView = [[UIImageView alloc] initWithFrame:CGRectMake(startX, 5, height - 10, height - 10)];
        heightImageView.image = [UIImage imageNamed:@"select_press"];
        [self addSubview:heightImageView];
        startX += height - 10;
        
        UILabel *heightLabel = [[UILabel alloc] initWithFrame:CGRectMake(startX, 0, width, height)];
        heightLabel.text = @"身高不限";
        heightLabel.font = myFont;
        [self addSubview:heightLabel];
        self.heightLabel = heightLabel;
        startX += width;
        
        UIImageView *genderImageView = [[UIImageView alloc] initWithFrame:CGRectMake(startX, 5, height - 10, height - 10)];
        genderImageView.image = [UIImage imageNamed:@"select_press"];
        [self addSubview:genderImageView];
        startX += height - 10;
        
        UILabel *genderLabel = [[UILabel alloc] initWithFrame:CGRectMake(startX, 0, width, height)];
        genderLabel.text = @"性别不限";
        genderLabel.font = myFont;
        [self addSubview:genderLabel];
        self.genderLabel = genderLabel;
        startX += width;
        
        UIImageView *ageImageView = [[UIImageView alloc] initWithFrame:CGRectMake(startX, 5, height - 10, height - 10)];
        ageImageView.image = [UIImage imageNamed:@"select_press"];
        [self addSubview:ageImageView];
        startX += height - 10;
        
        UILabel *ageLabel = [[UILabel alloc] initWithFrame:CGRectMake(startX, 0, width, height)];
        ageLabel.text = @"年龄不限";
        ageLabel.font = myFont;
        [self addSubview:ageLabel];
        self.ageLabel = ageLabel;
        startX += width;
        
        UIImageView *educationImageView = [[UIImageView alloc] initWithFrame:CGRectMake(startX, 5, height - 10, height - 10)];
        educationImageView.image = [UIImage imageNamed:@"select_press"];
        [self addSubview:educationImageView];
        startX += height - 10;
        
        UILabel *educationLabel = [[UILabel alloc] initWithFrame:CGRectMake(startX, 0, width, height)];
        educationLabel.text = @"学历不限";
        educationLabel.font = myFont;
        [self addSubview:educationLabel];
        self.educationLabel = educationLabel;
        startX += width;
    }
    return self;
}

@end
