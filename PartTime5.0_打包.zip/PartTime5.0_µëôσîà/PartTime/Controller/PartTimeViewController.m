//
//  PartTimeViewController.m
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "PartTimeViewController.h"
#import "HomeDetailsViewController.h"
#import "IGLDropDownMenu.h"

#import "CurrentPositionView.h"

#define MENU_WIDTH [UIScreen mainScreen].bounds.size.width/3

@interface PartTimeViewController ()<IGLDropDownMenuDelegate>
{
//    请求数据参数
    NSInteger pageNum;
    NSInteger jobTypeId;
    NSInteger distance;
    NSInteger sort;
}

@property (nonatomic, strong) IGLDropDownMenu *dropDownTypeMenu;
@property (nonatomic, strong) IGLDropDownMenu *dropDownDistanceMenu;
@property (nonatomic, strong) IGLDropDownMenu *dropDownSortMenu;

@property (nonatomic, strong) NSString *currentPosition;//记录当前位置

@end

@implementation PartTimeViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.sc_navigationItem.title = @"兼职列表";
    
    
    
//    初始化请求参数
    pageNum = 1;
    jobTypeId = 0;
    distance = 0;
    sort = 0;
    
    self.table.frame = CGRectMake(0, 64 + 40, SCREEN_WIDTH, SCREEN_HEIGHT - 64 - 49 - 40);
    
    __weak typeof(self) weakSelf = self;
    [self.table addLegendFooterWithRefreshingBlock:^{
        [weakSelf loadMoreData];
    }];
    
    [self createTypeMenuView];
    [self createDistanceMenuView];
    [self createSortMenuView];
}

#pragma mark --定位成功会触发监听通知的方法
- (void)getData:(NSNotification *)noti {
    NSDictionary *dic = noti.userInfo;
    lat = [[dic objectForKey:@"lat"] doubleValue];
    lon = [[dic objectForKey:@"lon"] doubleValue];
    
    //    请求数据
    [DownLoadData getPartTimeJobData:^(id obj, NSError *error) {
        if (obj) {
            self.dataSource = obj;
            [self.table reloadData];
        }else{
            NSLog(@"%@", error);
        }
        
        [HUD hide:YES];
    } withPageNum:(pageNum ++) withJobTypeId:jobTypeId withDistance:distance withSort:sort withLat:[NSNumber numberWithDouble:lat] withLon:[NSNumber numberWithDouble:lon]];
    
    //        反向编码成功，记录当前位置信息
    self.currentPosition = [dic objectForKey:@"position"];
    
    //        获取位置信息后，刷新分区头标题
    NSIndexSet *indexSet=[[NSIndexSet alloc]initWithIndex:0];
    [self.table reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
}

- (void)createTypeMenuView {
    NSArray *dataArray = @[@{@"image":@"",@"title":@"全部"},
                           @{@"image":@"",@"title":@"传单派发"},
                           @{@"image":@"",@"title":@"服务员"},
                           @{@"image":@"",@"title":@"促销导购"},
                           @{@"image":@"",@"title":@"模特礼仪"},
                           @{@"image":@"",@"title":@"电话销售"},
                           @{@"image":@"",@"title":@"小时工"},
                           @{@"image":@"",@"title":@"校园代理"},
                           @{@"image":@"",@"title":@"家教培训"}];
    NSMutableArray *dropdownItems = [[NSMutableArray alloc] init];
    for (int i = 0; i < dataArray.count; i++) {
        NSDictionary *dict = dataArray[i];
        
        IGLDropDownItem *item = [[IGLDropDownItem alloc] init];
        [item setIconImage:[UIImage imageNamed:dict[@"image"]]];
        [item setText:dict[@"title"]];
        [dropdownItems addObject:item];
        
    }
    
    self.dropDownTypeMenu = [[IGLDropDownMenu alloc] init];
    self.dropDownTypeMenu.menuText = @"全部";
    self.dropDownTypeMenu.dropDownItems = dropdownItems;
    self.dropDownTypeMenu.paddingLeft = 15;
    [self.dropDownTypeMenu setFrame:CGRectMake(0, 64, MENU_WIDTH, 30)];
    self.dropDownTypeMenu.delegate = self;
    
    self.dropDownTypeMenu.type = IGLDropDownMenuTypeStack;
    self.dropDownTypeMenu.flipWhenToggleView = YES;
    
    [self.dropDownTypeMenu reloadView];
    
    [self.view addSubview:self.dropDownTypeMenu];

    self.dropDownTypeMenu.tag = 1;
}

- (void)createDistanceMenuView {
    NSArray *dataArray = @[@{@"image":@"",@"title":@"全城"},
                           @{@"image":@"",@"title":@"1千米"},
                           @{@"image":@"",@"title":@"3千米"},
                           @{@"image":@"",@"title":@"5千米"},
                           @{@"image":@"",@"title":@"10千米"}];
    NSMutableArray *dropdownItems = [[NSMutableArray alloc] init];
    for (int i = 0; i < dataArray.count; i++) {
        NSDictionary *dict = dataArray[i];
        
        IGLDropDownItem *item = [[IGLDropDownItem alloc] init];
        [item setIconImage:[UIImage imageNamed:dict[@"image"]]];
        [item setText:dict[@"title"]];
        [dropdownItems addObject:item];
    }
    
    self.dropDownDistanceMenu = [[IGLDropDownMenu alloc] init];
    self.dropDownDistanceMenu.menuText = @"全城";
    self.dropDownDistanceMenu.dropDownItems = dropdownItems;
    self.dropDownDistanceMenu.paddingLeft = 15;
    [self.dropDownDistanceMenu setFrame:CGRectMake(MENU_WIDTH, 64, MENU_WIDTH, 30)];
    self.dropDownDistanceMenu.delegate = self;
    
    self.dropDownDistanceMenu.type = IGLDropDownMenuTypeStack;
    self.dropDownDistanceMenu.gutterY = 5;
    self.dropDownDistanceMenu.itemAnimationDelay = 0.1;
    self.dropDownDistanceMenu.rotate = IGLDropDownMenuRotateRandom;
    
    [self.dropDownDistanceMenu reloadView];
    
    [self.view addSubview:self.dropDownDistanceMenu];
    
    self.dropDownDistanceMenu.tag = 2;
}

- (void)createSortMenuView {
    NSArray *dataArray = @[@{@"image":@"",@"title":@"智能排序"},
                           @{@"image":@"",@"title":@"发布时间"},
                           @{@"image":@"",@"title":@"离我最近"}];
    NSMutableArray *dropdownItems = [[NSMutableArray alloc] init];
    for (int i = 0; i < dataArray.count; i++) {
        NSDictionary *dict = dataArray[i];
        
        IGLDropDownItem *item = [[IGLDropDownItem alloc] init];
        [item setIconImage:[UIImage imageNamed:dict[@"image"]]];
        [item setText:dict[@"title"]];
        [dropdownItems addObject:item];
    }
    
    self.dropDownSortMenu = [[IGLDropDownMenu alloc] init];
    self.dropDownSortMenu.menuText = @"智能排序";
    self.dropDownSortMenu.dropDownItems = dropdownItems;
    self.dropDownSortMenu.paddingLeft = 15;
    [self.dropDownSortMenu setFrame:CGRectMake(MENU_WIDTH * 2, 64, MENU_WIDTH, 30)];
    self.dropDownSortMenu.delegate = self;
    
    self.dropDownSortMenu.type = IGLDropDownMenuTypeStack;
    self.dropDownSortMenu.gutterY = 5;
    
    [self.dropDownSortMenu reloadView];
    
    [self.view addSubview:self.dropDownSortMenu];
    
    self.dropDownSortMenu.tag = 3;
}

#pragma mark --IGLDropDownMenuDelegate实现下拉菜单协议中的方法

//点击最上边的menu时会调用的协议中的方法（自己添加）
- (void)upOtherMenuWithMenu:(IGLDropDownMenu *)menu {
    for (int i = 0; i<3; i++) {
        IGLDropDownMenu *otherMenu = (IGLDropDownMenu *)[self.view viewWithTag:i + 1];
        if ((otherMenu.tag != menu.tag) & otherMenu.isExpanding) {
            otherMenu.expanding = NO;
        }
    }
}

- (void)selectedItemAtIndex:(NSInteger)index andItem:(IGLDropDownItem *)item
{

    IGLDropDownMenu *menu = (IGLDropDownMenu *)[item superview];
    
    if (menu.tag == 1) {
        NSLog(@"type");
        jobTypeId = index;
    }else if(menu.tag == 2){
        switch (index) {
            case 0:
                distance = 0;
                break;
            case 1:
                distance = 1;
                break;
            case 2:
                distance = 3;
                break;
            case 3:
                distance = 5;
                break;
            case 4:
                distance = 10;
                break;
                
            default:
                break;
        }
        
        NSLog(@"distance");
    }else{
        sort = index;
        NSLog(@"sort");
    }
    
    NSLog(@"index:%ld", (long)index);
    
//    先清空数据中内容,并设置pageNum为0
    [self.dataSource removeAllObjects];
    pageNum = 1;
//    重新设置刷新状态（避免结束刷新状态时，再选择其他选项后无法刷新）
    [self.table.footer resetNoMoreData];
    
//    请求数据
    [DownLoadData getPartTimeJobData:^(id obj, NSError *error) {
        if (obj) {
            self.dataSource = obj;
            [self.table reloadData];
        }else{
            NSLog(@"%@", error);
        }
        
    } withPageNum:(pageNum ++) withJobTypeId:jobTypeId withDistance:distance withSort:sort withLat:[NSNumber numberWithDouble:lat] withLon:[NSNumber numberWithDouble:lon]];
}

#pragma mark --下拉刷新
- (void)loadMoreData {
    
    [DownLoadData getPartTimeJobData:^(NSArray *obj, NSError *error) {
        if (obj) {
            [self.dataSource addObjectsFromArray:obj];
            [self.table reloadData];
        }else{
            NSLog(@"%@", error);
        }
        
        if (obj && obj.count>0) {
            // 拿到当前的上拉刷新控件，结束刷新状态
            [self.table.footer endRefreshing];
            
        }else{
            // 拿到当前的上拉刷新控件，变为没有更多数据的状态
            [self.table.footer noticeNoMoreData];
        }
        
    } withPageNum:(pageNum ++) withJobTypeId:jobTypeId withDistance:distance withSort:sort withLat:[NSNumber numberWithDouble:lat] withLon:[NSNumber numberWithDouble:lon]];
    
}


#pragma mark --UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *string = @"home";
    HomeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
    if (cell == nil) {
        cell = [[HomeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    HomeLatestModel *model = [self.dataSource objectAtIndex:indexPath.row];
    [cell updateInfoWithModel:model];
    
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (self.currentPosition) {
        return [NSString stringWithFormat:@"当前：%@", self.currentPosition];
    }
    return @"当前：";
}

#pragma mark --UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 30;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 10;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    HomeDetailsViewController *secondVC = [[HomeDetailsViewController alloc] init];
    HomeLatestModel *model = [self.dataSource objectAtIndex:indexPath.row];
    secondVC.jobId = model.myId;
    [self.navigationController pushViewController:secondVC animated:YES];
}

//- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
//    static NSString *string = @"header";
//    CurrentPositionView *currentPosition = [tableView dequeueReusableHeaderFooterViewWithIdentifier:string];
//    if (currentPosition == nil) {
//        currentPosition = [[CurrentPositionView alloc] initWithReuseIdentifier:string];
//        [currentPosition.refreshBtn addTarget:self action:@selector(pressBtn:) forControlEvents:UIControlEventTouchUpInside];
//        NSLog(@"header=============");
//    }
//    
//    NSLog(@"----------------------header");
//    return currentPosition;
//}
//
//- (void)pressBtn:(id)sender {
//    NSLog(@"++++++++++++++++++++++++++");
//}

@end
