//
//  HomeDetailsViewController.m
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "HomeDetailsViewController.h"
#import "CorpDetailViewController.h"

//点击按钮弹出菜单
#import "CHTumblrMenuView.h"

//shareSDK
#import <ShareSDK/ShareSDK.h>
#import <ShareSDKUI/ShareSDK+SSUI.h>

@interface HomeDetailsViewController ()

@property (nonatomic, strong) NSDictionary *dataDic;

@end

@implementation HomeDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
        
//    请求数据
    [DownLoadData getHomeLatestDetailsData:^(id obj, NSError *error) {
        if (obj) {
//            NSLog(@"%@", obj);
            self.dataDic = obj;
            [self.table reloadData];
        }else{
            NSLog(@"%@", error);
        }
        
        [HUD hide:YES];
    } withJobId:self.jobId];
    
    __weak typeof(self) weakSelf = self;
    
//    在导航栏上添加按钮
    
    SCBarButtonItem *rightItem = [[SCBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"menu_icon (1)"] style:SCBarButtonItemStylePlain handler:^(id sender) {
        [weakSelf showMenu];
    }];
    self.sc_navigationItem.rightBarButtonItem = rightItem;
}

#pragma mark --shareSDK实现分享功能
- (void)share {
    //创建分享参数
    NSArray* imageArray = @[[UIImage imageNamed:@"shareImg.png"]];
//    （注意：图片必须要在Xcode左边目录里面，名称必须要传正确，如果要分享网络图片，可以这样传iamge参数 images:@[@"http://mob.com/Assets/images/logo.png?v=20150320"]）
    if (imageArray) {
        
        NSMutableDictionary *shareParams = [NSMutableDictionary dictionary];
        [shareParams SSDKSetupShareParamsByText:@"分享内容"
                                         images:imageArray
                                            url:[NSURL URLWithString:@"http://mob.com"]
                                          title:@"分享标题"
                                           type:SSDKContentTypeAuto];
        //2、分享（可以弹出我们的分享菜单和编辑界面）
        [ShareSDK showShareActionSheet:nil //要显示菜单的视图, iPad版中此参数作为弹出菜单的参照视图，只有传这个才可以弹出我们的分享菜单，可以传分享的按钮对象或者自己创建小的view 对象，iPhone可以传nil不会影响
                                 items:nil
                           shareParams:shareParams
                   onShareStateChanged:^(SSDKResponseState state, SSDKPlatformType platformType, NSDictionary *userData, SSDKContentEntity *contentEntity, NSError *error, BOOL end) {
                       
                       switch (state) {
                           case SSDKResponseStateSuccess:
                           {
                               UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"分享成功"
                                                                                   message:nil
                                                                                  delegate:nil
                                                                         cancelButtonTitle:@"确定"
                                                                         otherButtonTitles:nil];
                               [alertView show];
                               break;
                           }
                           case SSDKResponseStateFail:
                           {
                               UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"分享失败"
                                                                               message:[NSString stringWithFormat:@"%@",error]
                                                                              delegate:nil
                                                                     cancelButtonTitle:@"OK"
                                                                     otherButtonTitles:nil, nil];
                               [alert show];
                               break;
                           }
                           default:
                               break;
                       }
                       
                   }];
    }
}

#pragma mark --导航栏右侧按钮响应事件
- (void)showMenu
{
    CHTumblrMenuView *menuView = [[CHTumblrMenuView alloc] init];
    __weak typeof(self) weakSelf = self;
    
//    公司详情
    [menuView addMenuItemWithTitle:@"公司详情" andIcon:[UIImage imageNamed:@"details.png"] andSelectedBlock:^{
        NSLog(@"details selected");
        [weakSelf pushToVC];
    }];
    
//    分享
    [menuView addMenuItemWithTitle:@"分享" andIcon:[UIImage imageNamed:@"share.png"] andSelectedBlock:^{
        NSLog(@"share selected");
        [weakSelf share];
        
    }];
//    [menuView addMenuItemWithTitle:@"collect" andIcon:[UIImage imageNamed:@"collect.png"] andSelectedBlock:^{
//        NSLog(@"collect selected");
//    }];
    
    [menuView show];
}


- (void)pushToVC {
    CorpDetailViewController *corpDetailVC = [[CorpDetailViewController alloc] initWithNibName:@"CorpDetailViewController" bundle:nil];
    corpDetailVC.corpId = self.dataDic[@"corpId"];
    [self.navigationController pushViewController:corpDetailVC animated:YES];
}

#pragma mark --UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *string;
    if (indexPath.section == 0) {
        string = @"info";
        InfoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
        if (cell == nil) {
            cell = [[InfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
        }
        [cell updateInfoWithDataDic:self.dataDic];
        return cell;
    }else if (indexPath.section == 1) {
        string = @"table";
        TableTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
        if (cell == nil) {
            cell = [[TableTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
        }
        [cell updateWithJobTime:[self.dataDic objectForKey:@"jobTime"]];
        return cell;
    }else if(indexPath.section == 2){
        string = @"describe";
        DescribeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
        if (cell == nil) {
            cell = [[DescribeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
        }
        [cell updateWithContent:[self.dataDic objectForKey:@"workContent"]];
        return cell;
    }else{
        string = @"alert";
        DescribeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
        if (cell == nil) {
            cell = [[DescribeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
        }
        [cell updateWithContent:[self.dataDic objectForKey:@"declaration"]];
        return cell;
    }
    
}

#pragma mark --UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        InfoTableViewCell *cell = (InfoTableViewCell *)[self tableView:tableView cellForRowAtIndexPath:indexPath];
        return cell.frame.size.height;
    }else if(indexPath.section == 1) {
        return 120;
    }
    DescribeTableViewCell *cell = (DescribeTableViewCell *)[self tableView:tableView cellForRowAtIndexPath:indexPath];
    return cell.frame.size.height;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section > 0) {
        return 30;
    }
    return 1;
}

//设置头标题
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    static NSString *header = @"time";
    
    UILabel *headerLabel = [tableView dequeueReusableHeaderFooterViewWithIdentifier:header];
    if (headerLabel == nil) {
        headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 30)];
    }
    headerLabel.backgroundColor = [UIColor whiteColor];
    
    
    if (section == 1) {
        headerLabel.text = @" 兼职时间";
    }else if (section == 2) {
        headerLabel.text = @" 兼职描述";
    }else if (section == 3) {
        headerLabel.text = @" 兼职提醒";
        headerLabel.textColor = [UIColor redColor];
    }
    return headerLabel;
}

@end
