//
//  SendViewController.m
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "SendViewController.h"
#import "SendDetailsViewController.h"

@interface SendViewController ()
{
    NSInteger pageNum;
}

@end

@implementation SendViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.sc_navigationItem.title = @"保送";
    pageNum = 1;
    
    __weak typeof(self) weakSelf = self;
    [self.table addLegendFooterWithRefreshingBlock:^{
        [weakSelf loadMoreData];
    }];
}

- (void)loadMoreData {
    
    [DownLoadData getSendJobData:^(NSArray *obj, NSError *error) {
        if (obj) {
            [self.dataSource addObjectsFromArray:obj];
            [self.table reloadData];
        }else{
            NSLog(@"%@", error);
        }
        
        if (obj && obj.count>0) {
            // 拿到当前的上拉刷新控件，结束刷新状态
            [self.table.footer endRefreshing];
            
        }else{
            // 拿到当前的上拉刷新控件，变为没有更多数据的状态
            [self.table.footer noticeNoMoreData];
        }
        
    } withPageNum:[NSNumber numberWithInteger:pageNum ++] withLat:[NSNumber numberWithDouble:lat] withLon:[NSNumber numberWithDouble:lon]];
    
}

#pragma mark --定位成功会触发监听通知的方法
- (void)getData:(NSNotification *)noti {
    NSDictionary *dic = noti.userInfo;
    lat = [[dic objectForKey:@"lat"] doubleValue];
    lon = [[dic objectForKey:@"lon"] doubleValue];
    
    //    请求数据
    [DownLoadData getSendJobData:^(id obj, NSError *error) {
        if (obj) {
            self.dataSource = obj;
            [self.table reloadData];
        }else{
            NSLog(@"%@", error);
        }
        
        [HUD hide:YES];
    } withPageNum:[NSNumber numberWithInteger:pageNum ++] withLat:[NSNumber numberWithDouble:lat] withLon:[NSNumber numberWithDouble:lon]];
}

#pragma mark --UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *string = @"send";
    SendTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
    if (cell == nil) {
        cell = [[SendTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
    }
    SendModel *model = [self.dataSource objectAtIndex:indexPath.row];
    [cell updateInfoWithModel:model];
    return cell;
}

#pragma mark --UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 150;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 10;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    SendDetailsViewController *sendDetailsVC = [[SendDetailsViewController alloc] init];
    SendModel *model = [self.dataSource objectAtIndex:indexPath.row];
    sendDetailsVC.jobId = model.jobId;
    [self.navigationController pushViewController:sendDetailsVC animated:YES];
}

@end
