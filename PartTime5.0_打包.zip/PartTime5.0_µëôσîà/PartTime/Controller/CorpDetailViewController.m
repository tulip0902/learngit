//
//  CorpDetailViewController.m
//  PartTime
//
//  Created by MS on 15-9-22.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "CorpDetailViewController.h"
#import "HomeDetailsViewController.h"

@interface CorpDetailViewController ()

@property (nonatomic, strong) NSDictionary *dataDic;

@end

@implementation CorpDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.sc_navigationItem.title = @"公司详情";
    
//    请求数据
    [DownLoadData getCorpData:^(id obj, NSError *error) {
        if (obj) {
//            NSLog(@"%@", obj);
            self.dataDic = obj;
            [self.table reloadData];
        }else{
            NSLog(@"%@",error);
        }
        
        [HUD hide:YES];
    } withCorpId:self.corpId];
    
//    请求商家职位列表信息
    [DownLoadData getCorpJobData:^(id obj, NSError *error) {
        if (obj) {
            NSLog(@"%@", obj);
            self.dataSource = obj;//dataSource存放商家职位列表信息
            [self.table reloadData];
        }else{
            NSLog(@"%@",error);
        }
    } withCorpId:self.corpId];
}

#pragma mark --UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 2) {
        return self.dataSource.count;
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *string;
    if (indexPath.section == 0) {
        string = @"corpInfo";
        CorpInfoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
        if (cell == nil) {
            cell = [[CorpInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
        }
        
        [cell updateInfoWithDataDic:self.dataDic];
        
        
        return cell;
    }
    if (indexPath.section == 1) {
        string = @"introduction";
        DescribeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
        if (cell == nil) {
            cell = [[DescribeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
        }
        
        [cell updateWithContent:self.dataDic[@"intro"]];
        
        return cell;
    }else if (indexPath.section == 2) {
        string = @"position";
        CropPositionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
        if (cell == nil) {
            cell = [[CropPositionTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
        }
        
        HomeLatestModel *model = [self.dataSource objectAtIndex:indexPath.row];
        [cell updateInfoWithModel:model];
        
        return cell;
        
    }
    UITableViewCell *cell = [[UITableViewCell alloc] init];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

#pragma mark --UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        CorpInfoTableViewCell *cell = (CorpInfoTableViewCell *)[self tableView:tableView cellForRowAtIndexPath:indexPath];
        return cell.frame.size.height;
    }else if (indexPath.section == 2) {
        return 60;
    }
    DescribeTableViewCell *cell = (DescribeTableViewCell *)[self tableView:tableView cellForRowAtIndexPath:indexPath];
    return cell.frame.size.height;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section > 0) {
        return 30;
    }
    return 1;
}

//设置头标题
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    static NSString *header = @"time";
    UILabel *headerLabel = [tableView dequeueReusableHeaderFooterViewWithIdentifier:header];
    if (headerLabel == nil) {
        headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 30)];
    }
    headerLabel.backgroundColor = [UIColor whiteColor];
    
    
    if (section == 1) {
        headerLabel.text = @" 商家简介";
    }else if (section == 2) {
        headerLabel.text = @" 商家职位";
    }
    
    return headerLabel;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 2) {
        HomeDetailsViewController *secondVC = [[HomeDetailsViewController alloc] init];
        HomeLatestModel *model = [self.dataSource objectAtIndex:indexPath.row];
        secondVC.jobId = model.myId;
        [self.navigationController pushViewController:secondVC animated:YES];

    }
    
}

@end
