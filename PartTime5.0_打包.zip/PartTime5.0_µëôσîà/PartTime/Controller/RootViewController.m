//
//  RootViewController.m
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "RootViewController.h"
#import "HomeViewController.h"
#import "PartTimeViewController.h"
#import "SendViewController.h"
#import "RDVTabBarItem.h"

#import <BaiduMapAPI/BMapKit.h>

@interface RootViewController ()<BMKLocationServiceDelegate, BMKGeoCodeSearchDelegate>
{
    BMKLocationService *_locService;
    BMKGeoCodeSearch *_searcher;
    BMKReverseGeoCodeOption *reverseGeoCodeSearchOption;
    
    //    用于记录经纬度
    CLLocationDegrees lat;
    CLLocationDegrees lon;
}

@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self setupViewControllers];
    
    _locService = [[BMKLocationService alloc]init];
    _locService.delegate = self;
    [BMKLocationService setLocationDistanceFilter:100];//设置定位的最小更新距离(米)
    [_locService startUserLocationService];
    
    //    ========================================================
    //    发起反向地理编码检索
    //初始化检索对象
    _searcher =[[BMKGeoCodeSearch alloc]init];
    _searcher.delegate = self;
    reverseGeoCodeSearchOption = [[BMKReverseGeoCodeOption alloc]init];
    //    ========================================================
    
    NSLog(@"root");
    
}

- (void)setupViewControllers {
    HomeViewController *homeVC = [[HomeViewController alloc]initWithNibName:@"HomeViewController" bundle:nil];
    SCNavigationController *homeNav = [[SCNavigationController alloc] initWithRootViewController:homeVC];
    
    PartTimeViewController *partTimeVC = [[PartTimeViewController alloc]initWithNibName:@"PartTimeViewController" bundle:nil];
    SCNavigationController *partTimeNav = [[SCNavigationController alloc] initWithRootViewController:partTimeVC];
    
    SendViewController *sendVC = [[SendViewController alloc]initWithNibName:@"SendViewController" bundle:nil];
    SCNavigationController *sendNav = [[SCNavigationController alloc] initWithRootViewController:sendVC];
    
    [self setViewControllers:@[homeNav, partTimeNav,sendNav]];
    
    [self customizeTabBarForController:self];
}

- (void)customizeTabBarForController:(RDVTabBarController *)tabBarController {
    NSArray *tabBarItemImages = @[@"tab_home", @"tab_area", @"tab_youji"];
    
    NSArray * titles = @[@"首页",@"兼职",@"保送"];
    
    NSDictionary *textAttributes_normal = nil;
    NSDictionary *textAttributes_selected = nil;
    
    if (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_6_1) {
        textAttributes_normal = @{
                                  NSFontAttributeName: [UIFont systemFontOfSize:12],
                                  NSForegroundColorAttributeName: [UIColor colorWithRed:65/255.0 green:65/255.0 blue:65/255.0 alpha:1.0],
                                  };
        textAttributes_selected = @{
                                    NSFontAttributeName: [UIFont systemFontOfSize:12],
                                    NSForegroundColorAttributeName: [UIColor colorWithRed:14/255.0 green:154/255.0 blue:255/255.0 alpha:1.0],
                                    };
    }
    
    
    
    NSInteger index = 0;
    for (RDVTabBarItem *item in [[tabBarController tabBar] items]) {
        
        item.unselectedTitleAttributes = textAttributes_normal;
        item.selectedTitleAttributes = textAttributes_selected;
        
        //        [item setBackgroundSelectedImage:finishedImage withUnselectedImage:unfinishedImage];
        UIImage *selectedimage = [UIImage imageNamed:[NSString stringWithFormat:@"%@_selected",
                                                      [tabBarItemImages objectAtIndex:index]]];
        UIImage *unselectedimage = [UIImage imageNamed:[NSString stringWithFormat:@"%@_normal",
                                                        [tabBarItemImages objectAtIndex:index]]];
        [item setFinishedSelectedImage:selectedimage withFinishedUnselectedImage:unselectedimage];
        
        item.title = titles[index];
        
        index++;
    }
}

#pragma mark --地图定位，实现协议中的方法
/**
 *用户位置更新后，会调用此函数
 *@param userLocation 新的用户位置
 */
- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation
{
    NSLog(@"didUpdateUserLocation lat %f,long %f",userLocation.location.coordinate.latitude,userLocation.location.coordinate.longitude);
    
//    定位成功后，将得到的经纬度保存起来
    lat = userLocation.location.coordinate.latitude;
    lon = userLocation.location.coordinate.longitude;
    
    //    定位成功后，反向地理编码（根据经纬度确定所在城市）
    
    [self reverseSearch:userLocation];
}

/**
 *在地图View停止定位后，会调用此函数
 *@param mapView 地图View
 */
- (void)didStopLocatingUser
{
    NSLog(@"stop locate");
}

/**
 *定位失败后，会调用此函数
 *@param mapView 地图View
 *@param error 错误号，参考CLError.h中定义的错误号
 */
- (void)didFailToLocateUserWithError:(NSError *)error
{
    NSLog(@"location error");
    NSLog(@"%@", error);
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"定位失败" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alert show];
}

#pragma mark --反向地理编码
- (void)reverseSearch:(BMKUserLocation *)userLocation {
    
    CLLocationCoordinate2D pt = (CLLocationCoordinate2D){userLocation.location.coordinate.latitude,userLocation.location.coordinate.longitude};
    reverseGeoCodeSearchOption.reverseGeoPoint = pt;
    BOOL flag = [_searcher reverseGeoCode:reverseGeoCodeSearchOption];
    reverseGeoCodeSearchOption = nil;
    NSString *searchResult;
    if(flag)
    {
        searchResult = @"反geo检索发送成功";
        NSLog(@"反geo检索发送成功");
    }
    else
    {
        searchResult = @"反geo检索发送失败";
        NSLog(@"反geo检索发送失败");
    }
//    
//    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:searchResult delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
//    [alert show];
}

//接收反向地理编码结果
-(void) onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:
(BMKReverseGeoCodeResult *)result
                        errorCode:(BMKSearchErrorCode)error{
    if (error == BMK_SEARCH_NO_ERROR) {
        //      在此处理正常结果
        
//        反向编码成功，发送通知，通知中包含经纬度，和当前位置信息
        [[NSNotificationCenter defaultCenter] postNotificationName:POSITION object:nil userInfo:@{@"position":result.address,@"lat":[NSNumber numberWithDouble:lat], @"lon":[NSNumber numberWithDouble:lon]}];
        
        NSLog(@"address : %@", result.address);
    }
    else {
        NSLog(@"抱歉，未找到结果");
    }
}


@end
