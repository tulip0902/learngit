//
//  SendDetailsViewController.h
//  PartTime
//
//  Created by MS on 15-9-21.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "SecondViewController.h"

@interface SendDetailsViewController : SecondViewController

@property (nonatomic, strong) NSNumber *jobId;

@end
