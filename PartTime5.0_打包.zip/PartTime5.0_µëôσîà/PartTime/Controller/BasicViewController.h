//
//  BasicViewController.h
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <BaiduMapAPI/BMapKit.h>

@interface BasicViewController : UIViewController<UITableViewDelegate, UITableViewDataSource, MBProgressHUDDelegate>
{
    MBProgressHUD *HUD;
    
    //    用于记录经纬度
    CLLocationDegrees lat;
    CLLocationDegrees lon;
}

@property (nonatomic, strong) NSMutableArray *dataSource;
@property (nonatomic, strong) UITableView *table;

@end
