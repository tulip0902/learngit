//
//  SendDetailsViewController.m
//  PartTime
//
//  Created by MS on 15-9-21.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "SendDetailsViewController.h"

@interface SendDetailsViewController ()

@property (nonatomic, strong) NSDictionary *dataDic;

@end

@implementation SendDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [DownLoadData getSendJobDetailsData:^(id obj, NSError *error) {
        if (obj) {
//            NSLog(@"%@", obj);
            self.dataDic = obj;
            [self.table reloadData];
        }else{
            NSLog(@"%@", error);
        }
        
        [HUD hide:YES];
    } withJobId:self.jobId];
    
}

#pragma mark --UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 7;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *string;
    if (indexPath.section == 0) {
        string = @"scroll";
        ScrollViewTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
        if (cell == nil) {
            cell = [[ScrollViewTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
        }
        if (self.dataDic) {
            NSString *imagePath = [self.dataDic objectForKey:@"jobImgScale"];
            NSArray *imagePathArr = [imagePath componentsSeparatedByString:@"|"];
            [cell showImagesAtScrollView:imagePathArr];
        }
        
        return cell;
    }else if (indexPath.section == 1) {
        string = @"sendDetails";
        SendDetailsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
        if (cell == nil) {
            cell = [[SendDetailsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell updateInfoWithDataDic:self.dataDic];
        return cell;
    }else{
        string = @"desc";
        DescribeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
        if (cell == nil) {
            cell = [[DescribeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
        }
        NSString *workContent = @"";
        NSString *salaryDesc = @"";
        NSString *recommendReason = @"";
        NSString *workRequire = @"";
        NSString *needKnow = @"";
        if (self.dataDic) {
            workContent = [self.dataDic objectForKey:@"workContent"];
            salaryDesc = [self.dataDic objectForKey:@"salaryDesc"];
            recommendReason = [self.dataDic objectForKey:@"recommendReason"];
            workRequire = [self.dataDic objectForKey:@"workRequire"];
            needKnow = [self.dataDic objectForKey:@"needKnow"];
        }
        
        NSArray *contentArr = @[workContent, salaryDesc, recommendReason, workRequire, needKnow];
        [cell updateWithContent:[contentArr objectAtIndex:indexPath.section - 2]];
        return cell;
    }
}

#pragma mark --UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return 150;
    }else if(indexPath.section == 1){
        SendDetailsTableViewCell *cell = (SendDetailsTableViewCell *)[self tableView:tableView cellForRowAtIndexPath:indexPath];
        return cell.frame.size.height;
    }
    DescribeTableViewCell *cell = (DescribeTableViewCell *)[self tableView:tableView cellForRowAtIndexPath:indexPath];
    return cell.frame.size.height;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section > 0) {
        return 30;
    }
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 10;
}

//设置头标题
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    static NSString *header = @"time";
    UILabel *headerLabel = [tableView dequeueReusableHeaderFooterViewWithIdentifier:header];
    if (headerLabel == nil) {
        headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 30)];
    }
    headerLabel.backgroundColor = [UIColor whiteColor];
    
    NSString *corpName = @"";
    if (self.dataDic) {
        corpName = [self.dataDic objectForKey:@"corpName"];
    }
    NSArray *titleArr = @[@"", corpName, @"工作内容", @"薪资说明", @"推荐理由", @"职位要求", @"求职须知"];

    headerLabel.text = [NSString stringWithFormat:@"  %@", [titleArr objectAtIndex:section]];
    return headerLabel;
}


@end
