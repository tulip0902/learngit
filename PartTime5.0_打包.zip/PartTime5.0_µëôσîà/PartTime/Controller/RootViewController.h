//
//  RootViewController.h
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "RDVTabBarController.h"

@interface RootViewController : RDVTabBarController

@end
