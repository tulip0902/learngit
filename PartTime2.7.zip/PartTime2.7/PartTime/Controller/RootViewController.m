//
//  RootViewController.m
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "RootViewController.h"
#import "HomeViewController.h"
#import "PartTimeViewController.h"
#import "SendViewController.h"
#import "RDVTabBarItem.h"

@interface RootViewController ()

@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self setupViewControllers];
}

- (void)setupViewControllers {
    HomeViewController *homeVC = [[HomeViewController alloc]initWithNibName:@"HomeViewController" bundle:nil];
    SCNavigationController *homeNav = [[SCNavigationController alloc] initWithRootViewController:homeVC];
    
    PartTimeViewController *partTimeVC = [[PartTimeViewController alloc]initWithNibName:@"PartTimeViewController" bundle:nil];
    SCNavigationController *partTimeNav = [[SCNavigationController alloc] initWithRootViewController:partTimeVC];
    
    SendViewController *sendVC = [[SendViewController alloc]initWithNibName:@"SendViewController" bundle:nil];
    SCNavigationController *sendNav = [[SCNavigationController alloc] initWithRootViewController:sendVC];
    
    [self setViewControllers:@[homeNav, partTimeNav,sendNav]];
    
    [self customizeTabBarForController:self];
}

- (void)customizeTabBarForController:(RDVTabBarController *)tabBarController {
    NSArray *tabBarItemImages = @[@"tab_home", @"tab_area", @"tab_youji"];
    
    NSArray * titles = @[@"首页",@"兼职",@"保送"];
    
    NSDictionary *textAttributes_normal = nil;
    NSDictionary *textAttributes_selected = nil;
    
    if (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_6_1) {
        textAttributes_normal = @{
                                  NSFontAttributeName: [UIFont systemFontOfSize:12],
                                  NSForegroundColorAttributeName: [UIColor colorWithRed:65/255.0 green:65/255.0 blue:65/255.0 alpha:1.0],
                                  };
        textAttributes_selected = @{
                                    NSFontAttributeName: [UIFont systemFontOfSize:12],
                                    NSForegroundColorAttributeName: [UIColor colorWithRed:14/255.0 green:154/255.0 blue:255/255.0 alpha:1.0],
                                    };
    }
    
    
    
    NSInteger index = 0;
    for (RDVTabBarItem *item in [[tabBarController tabBar] items]) {
        
        item.unselectedTitleAttributes = textAttributes_normal;
        item.selectedTitleAttributes = textAttributes_selected;
        
        //        [item setBackgroundSelectedImage:finishedImage withUnselectedImage:unfinishedImage];
        UIImage *selectedimage = [UIImage imageNamed:[NSString stringWithFormat:@"%@_selected",
                                                      [tabBarItemImages objectAtIndex:index]]];
        UIImage *unselectedimage = [UIImage imageNamed:[NSString stringWithFormat:@"%@_normal",
                                                        [tabBarItemImages objectAtIndex:index]]];
        [item setFinishedSelectedImage:selectedimage withFinishedUnselectedImage:unselectedimage];
        
        item.title = titles[index];
        
        index++;
    }
}

@end
