//
//  HomeDetailsViewController.m
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "HomeDetailsViewController.h"
#import "TableTableViewCell.h"

@interface HomeDetailsViewController ()

@property (nonatomic, strong) NSDictionary *dataDic;

@end

@implementation HomeDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
//    请求数据
    [DownLoadData getHomeLatestDetailsData:^(id obj, NSError *error) {
        if (obj) {
//            NSLog(@"%@", obj);
            self.dataDic = obj;
            [self.table reloadData];
        }else{
            NSLog(@"%@", error);
        }
        
        [HUD hide:YES];
    } withJobId:self.jobId];
}

#pragma mark --UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *string;
    if (indexPath.section == 0) {
        string = @"info";
        InfoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
        if (cell == nil) {
            cell = [[InfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
        }
//        标题
        cell.titleLabel.text = [self.dataDic objectForKey:@"name"];
//        工资待遇
        NSString *price = [Function getPriceWithPay:[self.dataDic objectForKey:@"pay"] andPayUnit:[self.dataDic objectForKey:@"payUnit"]];
        NSString *settle = [Function getSettleTypeWithId:[self.dataDic objectForKey:@"jobsettletypeId"]];
        cell.priceStrLabel.text = [NSString stringWithFormat:@"%@  [%@]", price, settle];
//        剩余人数
        cell.countStrLabel.text = [NSString stringWithFormat:@"%@人", [self.dataDic objectForKey:@"count"]];
//        有效时间
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy-MM-dd"];
        NSNumber *startTime = [self.dataDic objectForKey:@"startTime"];
        NSString *startTimeStr = [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:[startTime longLongValue]]];
        NSNumber *endTime = [self.dataDic objectForKey:@"endTime"];
        NSString *endTimeStr = [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:[endTime longLongValue]]];
        cell.timeStrLabel.text = [NSString stringWithFormat:@"%@ - %@", startTimeStr, endTimeStr];
//        工作地点
        cell.addressStrLabel.text = [self.dataDic objectForKey:@"address"];
//        招聘条件
        int sex = [[self.dataDic objectForKey:@"sex"] intValue];
        int grade = [[self.dataDic objectForKey:@"grade"] intValue];
        int minAge = [[self.dataDic objectForKey:@"minage"] intValue];
        int maxAge = [[self.dataDic objectForKey:@"maxage"] intValue];
        float height = [[self.dataDic objectForKey:@"height"] floatValue];
        cell.requestStrLabel.text = [Function getRequestWithSex:sex andGrade:grade andMinAge:minAge andMaxAge:maxAge andHeight:height];
        return cell;
    }else if (indexPath.section == 1) {
        string = @"table";
        TableTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
        if (cell == nil) {
            cell = [[TableTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
        }
        [cell updateWithJobTime:[self.dataDic objectForKey:@"jobTime"]];
        return cell;
    }else if(indexPath.section == 2){
        string = @"describe";
        DescribeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
        if (cell == nil) {
            cell = [[DescribeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
        }
        [cell updateWithContent:[self.dataDic objectForKey:@"workContent"]];
        return cell;
    }else{
        string = @"alert";
        DescribeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
        if (cell == nil) {
            cell = [[DescribeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
        }
        [cell updateWithContent:[self.dataDic objectForKey:@"declaration"]];
        return cell;
    }
    
}

#pragma mark --UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return 200;
    }else if(indexPath.section == 1) {
        return 120;
    }
    return 100;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section > 0) {
        return 30;
    }
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 10;
}

//设置头标题
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    static NSString *header = @"time";
    UILabel *headerLabel = [tableView dequeueReusableHeaderFooterViewWithIdentifier:header];
    if (headerLabel == nil) {
        headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 30)];
    }
    headerLabel.backgroundColor = [UIColor whiteColor];
    
    
    if (section == 1) {
        headerLabel.text = @"兼职时间";
    }else if (section == 2) {
        headerLabel.text = @"兼职描述";
    }else if (section == 3) {
        headerLabel.text = @"兼职提醒";
        headerLabel.textColor = [UIColor redColor];
    }
    return headerLabel;
}

@end
