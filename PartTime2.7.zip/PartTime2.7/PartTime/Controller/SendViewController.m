//
//  SendViewController.m
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "SendViewController.h"

@interface SendViewController ()
{
    NSInteger pageNum;
}

@end

@implementation SendViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.sc_navigationItem.title = @"保送";
    pageNum = 1;
    
//    请求数据
    [DownLoadData getSendJobData:^(id obj, NSError *error) {
        if (obj) {
            self.dataSource = obj;
            [self.table reloadData];
        }else{
            NSLog(@"%@", error);
        }
        
        [HUD hide:YES];
    } withPageNum:[NSNumber numberWithInteger:pageNum ++]];
    
    __weak typeof(self) weakSelf = self;
    [self.table addLegendFooterWithRefreshingBlock:^{
        [weakSelf loadMoreData];
    }];
}

- (void)loadMoreData {
    
    [DownLoadData getSendJobData:^(NSArray *obj, NSError *error) {
        if (obj) {
            [self.dataSource addObjectsFromArray:obj];
            [self.table reloadData];
        }else{
            NSLog(@"%@", error);
        }
        
        if (obj && obj.count>0) {
            // 拿到当前的上拉刷新控件，结束刷新状态
            [self.table.footer endRefreshing];
            
        }else{
            // 拿到当前的上拉刷新控件，变为没有更多数据的状态
            [self.table.footer noticeNoMoreData];
        }
        
    } withPageNum:[NSNumber numberWithInteger:pageNum ++]];
    
}


#pragma mark --UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *string = @"send";
    SendTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:string];
    if (cell == nil) {
        cell = [[SendTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
    }
    [cell updateInfoWithModel:[self.dataSource objectAtIndex:indexPath.row]];
    return cell;
}

#pragma mark --UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 150;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 10;
}


@end
