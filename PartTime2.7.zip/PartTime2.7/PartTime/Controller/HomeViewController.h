//
//  HomeViewController.h
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : BasicViewController

@end
