
#import "DownLoadData.h"
#import "AFAppDotNetAPIClient.h"

@implementation DownLoadData

//首页中滚动视图接口
//http://www.1mjz.com/v1/api/stu/banner/list?position=0
+ (NSURLSessionDataTask *)getHomeBannerData:(void (^) (id obj, NSError *error))block {
    NSString *path = @"v1/api/stu/banner/list?position=0";
    return [[AFAppDotNetAPIClient sharedClient] GET:path parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSLog(@"首页中滚动视图接口--数据下载成功");
//        NSLog(@"%@", responseObject);
        
        NSArray *dataArr = responseObject[@"data"];
        NSMutableArray *modelArr = [NSMutableArray array];
        
        [dataArr enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            HomeBannerModel *model = [[HomeBannerModel alloc] initWithDic:obj];
            [modelArr addObject:model];
        }];
        
        if (block) {
            block(modelArr, nil);
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"首页中滚动视图接口--数据下载失败");
        
        if (block) {
            block(nil, error);
        }
    }];
}

//首页中推荐职位接口
//http://www.1mjz.com/v1/api/stu/job/ad/list?cityId=34
+ (NSURLSessionDataTask *)getHomeADData:(void (^) (id obj, NSError *error))block {
    NSString *path = @"v1/api/stu/job/ad/list?cityId=34";
    return [[AFAppDotNetAPIClient sharedClient] GET:path parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSLog(@"首页中推荐职位接口--数据下载成功");
//        NSLog(@"%@", responseObject);
        
        NSArray *dataArr = responseObject[@"data"];
        NSMutableArray *modelArr = [NSMutableArray array];
        
        [dataArr enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            HomeADModel *model = [[HomeADModel alloc] initWithDic:obj];
            [modelArr addObject:model];
        }];
        
        if (block) {
            block(modelArr, nil);
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"首页中推荐职位接口--数据下载失败");
        
        if (block) {
            block(nil, error);
        }
    }];
}

//首页中最新职位接口
//http://www.1mjz.com/v1/api/stu/job/home/list?cityId=34&lat=40.037677&lon=116.371695
+ (NSURLSessionDataTask *)getHomeLatestData:(void (^) (id obj, NSError *error))block {
    NSString *path = @"v1/api/stu/job/home/list?cityId=34&lat=40.037677&lon=116.371695";
    return [[AFAppDotNetAPIClient sharedClient] GET:path parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSLog(@"首页中最新职位接口--数据下载成功");
//        NSLog(@"%@", responseObject);
        
        NSArray *dataArr = responseObject[@"data"];
        NSMutableArray *modelArr = [NSMutableArray array];
        
        [dataArr enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            HomeLatestModel *model = [[HomeLatestModel alloc] initWithDic:obj];
            [modelArr addObject:model];
        }];
        
        if (block) {
            block(modelArr, nil);
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"首页中最新职位接口--数据下载失败");
        
        if (block) {
            block(nil, error);
        }
    }];
}

//首页中最新职位详情接口
//http://www.1mjz.com/v1/api/stu/job/detail?jobId=88149&stuId=0
+ (NSURLSessionDataTask *)getHomeLatestDetailsData:(void (^) (id obj, NSError *error))block withJobId:(NSNumber *)jobId {
    NSString *path = [NSString stringWithFormat:@"v1/api/stu/job/detail?jobId=%@&stuId=0", jobId];
    return [[AFAppDotNetAPIClient sharedClient] GET:path parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSLog(@"职位详情接口--数据下载成功");
//        NSLog(@"%@", responseObject);
        
        NSDictionary *dataDic = responseObject[@"data"];
        
        if (block) {
            block(dataDic, nil);
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"职位详情接口--数据下载失败");
        
        if (block) {
            block(nil, error);
        }
    }];
}

//公司简介接口
//http://www.1mjz.com/v1/api/stu/corp/item?corpId=79984
+ (NSURLSessionDataTask *)getCorpData:(void (^) (id obj, NSError *error))block withCorpId:(NSNumber *)corpId {
    NSString *path = [NSString stringWithFormat:@"v1/api/stu/corp/item?corpId=%@", corpId];
    return [[AFAppDotNetAPIClient sharedClient] GET:path parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSLog(@"公司简介接口--数据下载成功");
//        NSLog(@"%@", responseObject);
        
        NSDictionary *dataDic = responseObject[@"data"];
        
        if (block) {
            block(dataDic, nil);
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"公司简介接口--数据下载失败");
        
        if (block) {
            block(nil, error);
        }
    }];
}

//公司简介中的商家职位接口
//http://www.1mjz.com/v1/api/stu/corp/job/list?corpId=79984
+ (NSURLSessionDataTask *)getCorpJobData:(void (^) (id obj, NSError *error))block withCorpId:(NSNumber *)corpId {
    NSString *path = [NSString stringWithFormat:@"v1/api/stu/corp/job/list?corpId=%@", corpId];
    return [[AFAppDotNetAPIClient sharedClient] GET:path parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSLog(@"公司简介中的商家职位接口--数据下载成功");
//        NSLog(@"%@", responseObject);
        
        NSArray *dataArr = responseObject[@"data"];
        NSMutableArray *modelArr = [NSMutableArray array];
        
        [dataArr enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            HomeLatestModel *model = [[HomeLatestModel alloc] initWithDic:obj];
            [modelArr addObject:model];
        }];
        
        if (block) {
            block(modelArr, nil);
        }
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"公司简介中的商家职位接口--数据下载失败");
        
        if (block) {
            block(nil, error);
        }
    }];
}

//兼职页面接口
//http://www.1mjz.com/v1/api/stu/job/list?cityId=34&jobTypeId=0&km=0&lat=40.037628&lon=116.369954&pageNum=1&pageSize=10&sort=0
+ (NSURLSessionDataTask *)getPartTimeJobData:(void (^) (id obj, NSError *error))block withPageNum:(NSNumber *)pageNum {
    NSString *path = [NSString stringWithFormat:@"v1/api/stu/job/list?cityId=34&jobTypeId=0&km=0&lat=40.037628&lon=116.369954&pageNum=%@&pageSize=10&sort=0", pageNum];
    return [[AFAppDotNetAPIClient sharedClient] GET:path parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSLog(@"兼职页面接口--数据下载成功");
//        NSLog(@"%@", responseObject);
        
        NSArray *dataArr = [responseObject[@"data"] objectForKey:@"list"];
        NSMutableArray *modelArr = [NSMutableArray array];
        
        [dataArr enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            HomeLatestModel *model = [[HomeLatestModel alloc] initWithDic:obj];
            [modelArr addObject:model];
        }];
        
        if (block) {
            block(modelArr, nil);
        }
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"兼职页面接口--数据下载失败");
        
        if (block) {
            block(nil, error);
        }
    }];
}

//保送页面接口
//http://www.1mjz.com/v1/api/stu/express/job/list?cityId=34&lat=40.037584&lon=116.36987&pageNum=1&pageSize=5
+ (NSURLSessionDataTask *)getSendJobData:(void (^) (id obj, NSError *error))block withPageNum:(NSNumber *)pageNum {
    NSString *path = [NSString stringWithFormat:@"v1/api/stu/express/job/list?cityId=34&lat=40.037584&lon=116.36987&pageNum=%@&pageSize=5", pageNum];
    return [[AFAppDotNetAPIClient sharedClient] GET:path parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSLog(@"保送页面接口--数据下载成功");
//        NSLog(@"%@", responseObject);
        
        NSArray *dataArr = [responseObject[@"data"] objectForKey:@"list"];
        NSMutableArray *modelArr = [NSMutableArray array];
        
        [dataArr enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            SendModel *model = [[SendModel alloc] initWithDic:obj];
            [modelArr addObject:model];
        }];
        
        if (block) {
            block(modelArr, nil);
        }
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"保送页面接口--数据下载失败");
        
        if (block) {
            block(nil, error);
        }
    }];
}

//保送页面详情接口
//http://www.1mjz.com/v1/api/stu/express/job/detail?jobId=101505
+ (NSURLSessionDataTask *)getSendJobDetailsData:(void (^) (id obj, NSError *error))block withJobId:(NSNumber *)jobId {
    NSString *path = [NSString stringWithFormat:@"v1/api/stu/express/job/detail?jobId=%@", jobId];
    return [[AFAppDotNetAPIClient sharedClient] GET:path parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSLog(@"保送页面详情接口--数据下载成功");
//        NSLog(@"%@", responseObject);
        
        NSDictionary *dataDic = responseObject[@"data"];
        
        if (block) {
            block(dataDic, nil);
        }
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"保送页面详情接口--数据下载失败");
        
        if (block) {
            block(nil, error);
        }
    }];

}

@end









