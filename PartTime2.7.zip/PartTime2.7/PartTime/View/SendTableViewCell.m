//
//  SendTableViewCell.m
//  PartTime
//
//  Created by MS on 15-9-21.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "SendTableViewCell.h"

@interface SendTableViewCell ()

@property (nonatomic, strong) UILabel *titleLabel;

@property (nonatomic, strong) UILabel *priceStr;
@property (nonatomic, strong) UILabel *positionStr;
@property (nonatomic, strong) UILabel *timeStr;
@property (nonatomic, strong) UILabel *addressStr;

@property (nonatomic, strong) UILabel *countLabel;
@property (nonatomic, strong) UILabel *remainingTimeLabel;
@property (nonatomic, strong) UILabel *distanceLabel;

@end

@implementation SendTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UIView *superView = self.contentView;
        superView.backgroundColor = [UIColor lightGrayColor];
        
        UIView *titleView = [[UIView alloc] init];
        titleView.backgroundColor = [UIColor whiteColor];
        titleView.layer.borderWidth = 1;
        titleView.layer.borderColor = [[UIColor colorWithWhite:0.917 alpha:1.000] CGColor];
        titleView.layer.masksToBounds = YES;
        [superView addSubview:titleView];
        
        UIView *contentView = [[UIView alloc] init];
        contentView.backgroundColor = [UIColor whiteColor];
        [superView addSubview:contentView];
        
        [titleView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(superView.mas_left).offset(0);
            make.top.equalTo(superView.mas_top).offset(0);
            make.right.equalTo(superView.mas_right).offset(0);
            make.bottom.equalTo(contentView.mas_top).offset(0);
            make.height.equalTo(@30);
        }];
        
        [contentView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(superView.mas_left).offset(0);
            make.right.equalTo(superView.mas_right).offset(0);
            make.bottom.equalTo(superView.mas_bottom).offset(-10);
        }];
        
#pragma mark --在titleView上添加label
        UILabel *titleLabel = [[UILabel alloc] init];
//        titleLabel.backgroundColor = [UIColor redColor];
        [titleView addSubview:titleLabel];
        self.titleLabel = titleLabel;
        
        UILabel *lookLabel = [[UILabel alloc] init];
//        lookLabel.backgroundColor = [UIColor grayColor];
        lookLabel.text = @"查看详情";
        lookLabel.textAlignment = NSTextAlignmentRight;
        lookLabel.font = [UIFont systemFontOfSize:14];
        lookLabel.textColor = [UIColor lightGrayColor];
        [titleView addSubview:lookLabel];
        
        UIImageView *rightImageView = [[UIImageView alloc] init];
//        rightImageView.backgroundColor = [UIColor purpleColor];
        rightImageView.image = [UIImage imageNamed:@"arrow_right"];
        [titleView addSubview:rightImageView];
        
        [rightImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(titleView.mas_top).offset(5);
            make.right.equalTo(titleView.mas_right).offset(-5);
            make.bottom.equalTo(titleView.mas_bottom).offset(-5);
            make.width.equalTo(rightImageView.mas_height);
        }];
        
        [lookLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(titleView.mas_top).offset(0);
            make.right.equalTo(rightImageView.mas_left).offset(0);
            make.bottom.equalTo(titleView.mas_bottom).offset(0);
            make.width.equalTo(@70);
        }];
        
        [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(titleView.mas_left).offset(5);
            make.top.equalTo(titleView.mas_top).offset(0);
            make.right.equalTo(lookLabel.mas_left).offset(0);
            make.bottom.equalTo(titleView.mas_bottom).offset(0);
        }];
        
#pragma mark --contentView上的label
        UIFont *myFont = [UIFont systemFontOfSize:14];
        UIColor *myTextColor = [UIColor grayColor];
        
        UILabel *priceLabel = [[UILabel alloc] init];
        priceLabel.text = @"工资待遇:";
        priceLabel.font = myFont;
        priceLabel.textColor = myTextColor;
        [superView addSubview:priceLabel];
        
        UILabel *positionLabel = [[UILabel alloc] init];
        positionLabel.text = @"工作职位:";
        positionLabel.font = myFont;
        positionLabel.textColor = myTextColor;
        [superView addSubview:positionLabel];
        
        UILabel *timeLabel = [[UILabel alloc] init];
        timeLabel.text = @"工作时间:";
        timeLabel.font = myFont;
        timeLabel.textColor = myTextColor;
        [superView addSubview:timeLabel];
        
        UILabel *addressLabel = [[UILabel alloc] init];
        addressLabel.text = @"工作地点:";
        addressLabel.font = myFont;
        addressLabel.textColor = myTextColor;
        [superView addSubview:addressLabel];

        [priceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(contentView.mas_left).offset(5);
            make.top.equalTo(contentView.mas_top).offset(5);
            make.bottom.equalTo(positionLabel.mas_top).offset(0);
            make.width.equalTo(@70);
            make.height.equalTo(@[positionLabel, timeLabel, addressLabel]);
        }];
        
        [positionLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(contentView.mas_left).offset(5);
            make.bottom.equalTo(timeLabel.mas_top).offset(0);
            make.width.equalTo(@70);
        }];
        
        [timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(contentView.mas_left).offset(5);
            make.bottom.equalTo(addressLabel.mas_top).offset(0);
            make.width.equalTo(@70);
        }];
        
        [addressLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(contentView.mas_left).offset(5);
            make.bottom.equalTo(contentView.mas_bottom).offset(-5);
            make.width.equalTo(@70);
        }];
        
        UILabel *priceStr = [[UILabel alloc] init];
//        priceStr.backgroundColor = [UIColor redColor];
        priceStr.textColor = [UIColor colorWithRed:0.984 green:0.653 blue:0.325 alpha:1.000];
        [contentView addSubview:priceStr];
        self.priceStr = priceStr;
        
        [priceStr mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(priceLabel.mas_right).offset(0);
            make.top.equalTo(contentView.mas_top).offset(5);
            make.width.equalTo(@100);
            make.height.equalTo(priceLabel.mas_height);
        }];
        
//        剩余人数
        UILabel *countLabel = [[UILabel alloc] init];
        countLabel.font = myFont;
        countLabel.textColor = [UIColor colorWithRed:0.000 green:0.728 blue:0.000 alpha:1.000];
        [contentView addSubview:countLabel];
        self.countLabel = countLabel;

//        剩余时间
        UILabel *remainingTimeLabel = [[UILabel alloc] init];
        remainingTimeLabel.font = myFont;
        remainingTimeLabel.textColor = [UIColor colorWithRed:0.000 green:0.728 blue:0.000 alpha:1.000];
        [contentView addSubview:remainingTimeLabel];
        self.remainingTimeLabel = remainingTimeLabel;
        
//        距离
        UILabel *distanceLabel = [[UILabel alloc] init];
        distanceLabel.font = myFont;
        distanceLabel.textColor = myTextColor;
        distanceLabel.textAlignment = NSTextAlignmentRight;
        [contentView addSubview:distanceLabel];
        self.distanceLabel = distanceLabel;
        
        [countLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(positionLabel.mas_centerY);
            make.right.equalTo(contentView.mas_right).offset(0);
            make.height.equalTo(positionLabel);
            make.width.equalTo(@70);
        }];
        
        [remainingTimeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(timeLabel.mas_centerY);
            make.right.equalTo(contentView.mas_right).offset(0);
            make.height.equalTo(timeLabel);
            make.width.equalTo(@90);
        }];
        
        [distanceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(addressLabel.mas_centerY);
            make.right.equalTo(contentView.mas_right).offset(-10);
            make.height.equalTo(addressLabel);
            make.width.equalTo(@70);
        }];
        
//        添加仅剩人数和时间的图标
        UIImageView *countImageView = [[UIImageView alloc] init];
        countImageView.image = [UIImage imageNamed:@"mijie_rentouxiang"];
        [contentView addSubview:countImageView];
        
        UIImageView *timeImageView = [[UIImageView alloc] init];
        timeImageView.image = [UIImage imageNamed:@"mijie_naozhong"];
        [contentView addSubview:timeImageView];
        
        [countImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(positionLabel.mas_centerY);
            make.right.equalTo(countLabel.mas_left).offset(0);
            make.height.equalTo(positionLabel).multipliedBy(2/3.0);
            make.width.equalTo(countImageView.mas_height);
        }];
        
        [timeImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(timeLabel.mas_centerY);
            make.right.equalTo(remainingTimeLabel.mas_left).offset(0);
            make.height.equalTo(timeLabel).multipliedBy(2/3.0);
            make.width.equalTo(timeImageView.mas_height);
        }];
        
        
//        添加中间部分用于显示内容的label
        UILabel *positionStr = [[UILabel alloc] init];
        positionStr.font = myFont;
        positionStr.textColor = myTextColor;
        [contentView addSubview:positionStr];
        self.positionStr = positionStr;
        
        UILabel *timeStr = [[UILabel alloc] init];
        timeStr.font = myFont;
        timeStr.textColor = myTextColor;
        [contentView addSubview:timeStr];
        self.timeStr = timeStr;
        
        UILabel *addressStr = [[UILabel alloc] init];
        addressStr.font = myFont;
        addressStr.textColor = myTextColor;
        [contentView addSubview:addressStr];
        self.addressStr = addressStr;
        
        [positionStr mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(positionLabel.mas_centerY);
            make.left.equalTo(positionLabel.mas_right).offset(0);
            make.right.equalTo(countImageView.mas_left).offset(0);
            make.height.equalTo(positionLabel);
        }];
        
        [timeStr mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(timeLabel.mas_centerY);
            make.left.equalTo(timeLabel.mas_right).offset(0);
            make.right.equalTo(timeImageView.mas_left).offset(0);
            make.height.equalTo(timeLabel);
        }];
        
        [addressStr mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(addressLabel.mas_centerY);
            make.left.equalTo(addressLabel.mas_right).offset(0);
            make.right.equalTo(distanceLabel.mas_left).offset(0);
            make.height.equalTo(addressLabel);
        }];
        
    }
    return self;
}

- (void)updateInfoWithModel:(SendModel *)model {
    self.titleLabel.text = model.corpName;
    
    self.priceStr.text = [Function getPriceWithPay:model.pay andPayUnit:model.payunit];
    
    self.countLabel.text = [NSString stringWithFormat:@"仅剩%@人", model.oddNum];
    
//    设置剩余时间
    NSDate *endDate = [NSDate dateWithTimeIntervalSince1970:[model.regiEndTime longLongValue]];
    NSTimeInterval remainingTime = [endDate timeIntervalSinceDate:[NSDate date]];
    NSInteger remainingH = remainingTime / 3600;
    if ((remainingTime/3600 - remainingH) == 0) {
        self.remainingTimeLabel.text = [NSString stringWithFormat:@"仅剩%ld小时", remainingH];
    }else{
        self.remainingTimeLabel.text = [NSString stringWithFormat:@"仅剩%ld小时", remainingH + 1];
    }
    
//设置距离
    self.distanceLabel.text = [NSString stringWithFormat:@"%.1fkm", [model.distance intValue] / 1000.f];
    
//    设置内容
    self.positionStr.text = model.jobName;
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    NSString *dateStr = [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:[model.jobDate longLongValue]]];
    self.timeStr.text = dateStr;
    
    self.addressStr.text = model.address;
    
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
