//
//  TableTableViewCell.m
//  PartTime
//
//  Created by MS on 15-9-19.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "TableTableViewCell.h"

@implementation TableTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
//        获取每个小个的宽和高
        CGFloat width = (SCREEN_WIDTH - 10)/8;
        CGFloat height = (120-10)/4;
        
        NSArray *weekArr = @[@"周一", @"周二", @"周三", @"周四", @"周五", @"周六", @"周日"];
        NSArray *timeArr = @[@"上午", @"下午", @"晚上"];
        
        NSLog(@"self.height = %f", self.contentView.frame.size.height);
        for (int i = 0; i<4; i++) {
            for (int j = 0; j<8; j++) {
                UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(5+j*width, 5+i*height, width, height)];
                label.backgroundColor = [UIColor brownColor];
                label.layer.borderWidth = 0.5;
                label.layer.borderColor = [[UIColor blackColor] CGColor];
                label.layer.masksToBounds = YES;
                label.textAlignment = NSTextAlignmentCenter;
                [self.contentView addSubview:label];
                label.tag = i * 8 + j + 100;
                
                if (i == 0 & j > 0) {
                    label.text = weekArr[j - 1];
                }
                
                if (j == 0 & i > 0) {
                    label.text = timeArr[i - 1];
                }
                
                if (i == 0 | j == 0) {
                    label.backgroundColor = [UIColor colorWithWhite:0.726 alpha:1.000];
                }else{
                    label.backgroundColor = [UIColor whiteColor];
                    label.font = [UIFont systemFontOfSize:12];
                }
            }
        }
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}

- (void)updateWithJobTime:(NSString *)jobTime {
    NSCharacterSet *set = [NSCharacterSet characterSetWithCharactersInString:@",|"];
    NSArray * arr = [jobTime componentsSeparatedByCharactersInSet:set];
    
    for (int i = 0; i<8; i++) {
        for (int j = 0; j<4; j++) {
            if (i > 0 && j > 0) {
                UILabel *label = (UILabel *)[self.contentView viewWithTag:i + j * 8 + 100];
                label.text = @"";
                if ([arr[(i-1)*3+j-1] intValue] == 1) {
                    label.text = @"√";
                }
                
            }
        }
        
    }
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
