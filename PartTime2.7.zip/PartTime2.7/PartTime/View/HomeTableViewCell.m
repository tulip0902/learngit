//
//  HomeTableViewCell.m
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "HomeTableViewCell.h"

@interface HomeTableViewCell ()
@property (nonatomic, strong) UILabel *jobContent;
@property (nonatomic, strong) UILabel *corpName;
@property (nonatomic, strong) UILabel *price;
@property (nonatomic, strong) UILabel *count;
@property (nonatomic, strong) UILabel *time;
@property (nonatomic, strong) UILabel *distance;
@property (nonatomic, strong) UILabel *settleType;

@end

@implementation HomeTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        UIView *superView = self.contentView;
        
        UILabel *jobContent = [[UILabel alloc] init];
        [superView addSubview:jobContent];
        self.jobContent = jobContent;
        self.jobContent.textColor = [UIColor blueColor];
        
        UILabel *corpName = [[UILabel alloc] init];
        [superView addSubview:corpName];
        self.corpName = corpName;
        self.corpName.font = [UIFont systemFontOfSize:12];
        self.corpName.textColor = [UIColor colorWithWhite:0.403 alpha:1.000];
        
        UILabel *price = [[UILabel alloc] init];
        [superView addSubview:price];
        self.price = price;
        self.price.textColor = [UIColor colorWithRed:0.840 green:0.558 blue:0.278 alpha:1.000];
        
        UILabel *count = [[UILabel alloc] init];
        [superView addSubview:count];
        self.count = count;
        self.count.font = [UIFont systemFontOfSize:12];
        self.count.textColor = [UIColor colorWithWhite:0.403 alpha:1.000];
        
        UILabel *time = [[UILabel alloc] init];
        [superView addSubview:time];
        self.time = time;
        self.time.textAlignment = NSTextAlignmentRight;
        self.time.font = [UIFont systemFontOfSize:12];
        
        UILabel *distance = [[UILabel alloc] init];
        [superView addSubview:distance];
        self.distance = distance;
        self.distance.textAlignment = NSTextAlignmentRight;
        self.distance.font = [UIFont systemFontOfSize:12];
        self.distance.textColor = [UIColor colorWithRed:0.000 green:0.658 blue:0.000 alpha:1.000];
        
        UILabel *settleType = [[UILabel alloc] init];
        [superView addSubview:settleType];
        self.settleType = settleType;
        self.settleType.textAlignment = NSTextAlignmentCenter;
        self.settleType.layer.cornerRadius = 6;
        self.settleType.layer.masksToBounds = YES;
        self.settleType.backgroundColor = [UIColor purpleColor];
        self.settleType.textColor = [UIColor whiteColor];
        self.settleType.font = [UIFont systemFontOfSize:14];
        
        [jobContent mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(superView.mas_left).offset(10);
            make.top.equalTo(superView.mas_top).offset(5);
            make.right.equalTo(time.mas_left).offset(-5);
            make.bottom.equalTo(corpName.mas_top).offset(-5);
            make.height.equalTo(@[corpName, price, count, time, distance]);
        }];
        
        [corpName mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(superView.mas_left).offset(10);
            make.right.equalTo(distance.mas_left).offset(-5);
            make.bottom.equalTo(price.mas_top).offset(-5);
        }];
        
        [self.price mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView.mas_left).offset(10);
            make.right.equalTo(self.count.mas_left).offset(-5);
            make.bottom.equalTo(self.contentView.mas_bottom).offset(-5);
            make.width.equalTo(@100);
        }];

        [self.count mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.corpName.mas_bottom).offset(5);
            make.width.equalTo(@80);
        }];
        
        [time mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(superView.mas_top).offset(5);
            make.right.equalTo(superView.mas_right).offset(-10);
            make.bottom.equalTo(distance.mas_top).offset(-5);
            make.width.equalTo(@80);
        }];
        
        [distance mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(superView.mas_right).offset(-10);
            make.bottom.equalTo(settleType.mas_top).offset(-5);
            make.width.equalTo(@80);
        }];
        
        [settleType mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(superView.mas_right).offset(-10);
            make.bottom.equalTo(superView.mas_bottom).offset(-5);
            make.width.equalTo(@40);
        }];
        
    }
    return self;
}

- (void)updateInfoWithModel:(HomeLatestModel *)model {
    
    self.jobContent.text = model.name;
    
    self.corpName.text = model.corpName;
    
    self.price.text = [Function getPriceWithPay:model.pay andPayUnit:model.payUnit];
    
    
    self.count.text = [NSString stringWithFormat:@"剩余%d人", [model.count intValue]];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    NSString *timeStr = [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:[model.freshTime longLongValue]]];
    self.time.text = timeStr;
    
    self.distance.text = [NSString stringWithFormat:@"%.1fkm", [model.distance floatValue]/1000];
    
    self.settleType.text = [Function getSettleTypeWithId:model.jobsettletypeId];
    NSArray *colorArr = @[[UIColor colorWithRed:0.897 green:0.062 blue:0.324 alpha:1.000], [UIColor colorWithRed:0.637 green:0.445 blue:0.957 alpha:1.000], [UIColor colorWithRed:0.903 green:0.466 blue:0.202 alpha:1.000], [UIColor colorWithRed:0.000 green:0.696 blue:0.000 alpha:1.000]];
    NSInteger settleType = [model.jobsettletypeId integerValue];
    self.settleType.backgroundColor = colorArr[settleType - 1];
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void) layoutSubviews {
    [super layoutSubviews];
    self.backgroundView.frame = CGRectMake(9, 0, 302, 44);
    self.selectedBackgroundView.frame = CGRectMake(9, 0, 302, 44);
}

@end
