//
//  InfoTableViewCell.m
//  PartTime
//
//  Created by tulip on 15-9-20.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "InfoTableViewCell.h"

@implementation InfoTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        UIView *superView = self.contentView;
        CGFloat padding = 5;
        CGFloat leftLabelWidth = 70;
        
        UIFont *myFont = [UIFont systemFontOfSize:14];
        
        UILabel *titleLabel = [[UILabel alloc] init];
        [superView addSubview:titleLabel];
        self.titleLabel = titleLabel;
        
        UILabel *priceLabel = [[UILabel alloc] init];
        priceLabel.text = @"工资待遇:";
        priceLabel.font = myFont;
        [superView addSubview:priceLabel];
        
        UILabel *countLabel = [[UILabel alloc] init];
        countLabel.text = @"剩余人数:";
        countLabel.font = myFont;
        [superView addSubview:countLabel];
        
        UILabel *timeLabel = [[UILabel alloc] init];
        timeLabel.text = @"有效时间:";
        timeLabel.font = myFont;
        [superView addSubview:timeLabel];
        
        UILabel *addressLabel = [[UILabel alloc] init];
        addressLabel.text = @"工作地点:";
        addressLabel.font = myFont;
        [superView addSubview:addressLabel];
        
        UILabel *requestLabel = [[UILabel alloc] init];
        requestLabel.text = @"招聘条件:";
        requestLabel.font = myFont;
        [superView addSubview:requestLabel];
        
//        约束
        [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(superView.mas_left).offset(padding);
            make.top.equalTo(superView.mas_top).offset(padding);
            make.right.equalTo(superView.mas_right).offset(-padding);
            make.bottom.equalTo(priceLabel.mas_top).offset(-padding);
            make.height.equalTo(@[priceLabel, countLabel, timeLabel, addressLabel, requestLabel]);
        }];
        
        [priceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(superView.mas_left).offset(padding);
            make.bottom.equalTo(countLabel.mas_top).offset(-padding);
            make.width.equalTo(@(leftLabelWidth));
        }];
        
        [countLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(superView.mas_left).offset(padding);
            make.bottom.equalTo(timeLabel.mas_top).offset(-padding);
            make.width.equalTo(@(leftLabelWidth));
        }];
        
        [timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(superView.mas_left).offset(padding);
            make.bottom.equalTo(addressLabel.mas_top).offset(-padding);
            make.width.equalTo(@(leftLabelWidth));
        }];
        
        [addressLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(superView.mas_left).offset(padding);
            make.bottom.equalTo(requestLabel.mas_top).offset(-padding);
            make.width.equalTo(@(leftLabelWidth));
        }];
        
        [requestLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(superView.mas_left).offset(padding);
            make.bottom.equalTo(superView.mas_bottom).offset(-padding);
            make.width.equalTo(@(leftLabelWidth));
        }];
        
        UILabel *priceStrLabel = [[UILabel alloc] init];
        priceStrLabel.font = myFont;
        priceStrLabel.numberOfLines = 0;
        [superView addSubview:priceStrLabel];
        self.priceStrLabel = priceStrLabel;
        
        UILabel *countStrLabel = [[UILabel alloc] init];
        countStrLabel.font = myFont;
        countStrLabel.numberOfLines = 0;
        [superView addSubview:countStrLabel];
        self.countStrLabel = countStrLabel;
        
        UILabel *timeStrLabel = [[UILabel alloc] init];
        timeStrLabel.font = myFont;
        timeStrLabel.numberOfLines = 0;
        [superView addSubview:timeStrLabel];
        self.timeStrLabel = timeStrLabel;
        
        UILabel *addressStrLabel = [[UILabel alloc] init];
        addressStrLabel.font = myFont;
        addressStrLabel.numberOfLines = 0;
        [superView addSubview:addressStrLabel];
        self.addressStrLabel = addressStrLabel;
        
        UILabel *requestStrLabel = [[UILabel alloc] init];
        requestStrLabel.font = myFont;
        requestStrLabel.numberOfLines = 0;
        [superView addSubview:requestStrLabel];
        self.requestStrLabel = requestStrLabel;
        
        [priceStrLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(priceLabel.mas_right).offset(padding);
            make.top.equalTo(titleLabel.mas_bottom).offset(padding);
            make.right.equalTo(superView.mas_right).offset(-padding);
            make.bottom.equalTo(countStrLabel.mas_top).offset(-padding);
            make.height.equalTo(@[countStrLabel, timeStrLabel, addressStrLabel, requestStrLabel]);
        }];
        
        [countStrLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(countLabel.mas_right).offset(padding);
            make.right.equalTo(superView.mas_right).offset(-padding);
            make.bottom.equalTo(timeStrLabel.mas_top).offset(-padding);
        }];
        
        [timeStrLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(timeLabel.mas_right).offset(padding);
            make.right.equalTo(superView.mas_right).offset(-padding);
            make.bottom.equalTo(addressStrLabel.mas_top).offset(-padding);
        }];
        
        [addressStrLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(addressLabel.mas_right).offset(padding);
            make.right.equalTo(superView.mas_right).offset(-padding);
            make.bottom.equalTo(requestStrLabel.mas_top).offset(-padding);
        }];
        
        [requestStrLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(requestLabel.mas_right).offset(padding);
            make.right.equalTo(superView.mas_right).offset(-padding);
            make.bottom.equalTo(superView.mas_bottom).offset(-padding);
        }];
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
