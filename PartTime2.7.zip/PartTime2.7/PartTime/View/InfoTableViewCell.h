//
//  InfoTableViewCell.h
//  PartTime
//
//  Created by tulip on 15-9-20.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfoTableViewCell : UITableViewCell

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *priceStrLabel;
@property (nonatomic, strong) UILabel *countStrLabel;
@property (nonatomic, strong) UILabel *timeStrLabel;
@property (nonatomic, strong) UILabel *addressStrLabel;
@property (nonatomic, strong) UILabel *requestStrLabel;

@end
