//
//  Function.h
//  PartTime
//
//  Created by tulip on 15-9-20.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Function : NSObject

//输入金额和类型，返回一个字符串
+ (NSString *)getPriceWithPay:(NSNumber *)pay andPayUnit:(NSNumber *)payUnit;

//根据数据的结算类型，返回对应的字符串
+ (NSString *)getSettleTypeWithId:(NSNumber *)jobsettletypeId;

//根据性别，学历，年龄，身高，返回一个字符串
+ (NSString *)getRequestWithSex:(int)sex andGrade:(int)grade andMinAge:(int)minAge andMaxAge:(int)maxAge andHeight:(float)height;

@end
