//
//  HomeLatestModel.h
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HomeLatestModel : NSObject

@property (nonatomic, strong) NSNumber *cityId;
@property (nonatomic, strong) NSNumber *clickNum;
@property (nonatomic, strong) NSNumber *confirmNum;
@property (nonatomic, strong) NSNumber *corpId;
@property (nonatomic, strong) NSString *corpLogo;
@property (nonatomic, strong) NSString *corpName;
@property (nonatomic, strong) NSNumber *corpRank;
@property (nonatomic, strong) NSNumber *count;
@property (nonatomic, strong) NSNumber *creatTime;
@property (nonatomic, strong) NSNumber *distance;
@property (nonatomic, strong) NSNumber *freshTime;
@property (nonatomic, strong) NSNumber *myId;//id
@property (nonatomic, strong) NSNumber *jobsettletypeId;
@property (nonatomic, strong) NSNumber *jobtimetypeId;
@property (nonatomic, strong) NSNumber *jobtypeId;
@property (nonatomic, strong) NSNumber *lat;
@property (nonatomic, strong) NSNumber *lon;
@property (nonatomic, strong) NSNumber *modifTime;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSNumber *pay;
@property (nonatomic, strong) NSNumber *payUnit;
@property (nonatomic, strong) NSNumber *regiNum;

- (instancetype)initWithDic:(NSDictionary *)dic;

+ (HomeLatestModel *)homeLatesModelWithDic:(NSDictionary *)dic;

@end
