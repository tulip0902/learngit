//
//  SendModel.m
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "SendModel.h"

@implementation SendModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

- (id)valueForUndefinedKey:(NSString *)key {
    return nil;
}

- (instancetype)initWithDic:(NSDictionary *)dic {
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dic];
    }
    return self;
}

+ (SendModel *)sendModelWithDic:(NSDictionary *)dic {
    SendModel *model = [[SendModel alloc] initWithDic:dic];
    return model;
}

@end
