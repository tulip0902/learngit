//
//  SendModel.h
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SendModel : NSObject

@property (nonatomic, strong) NSString *address;
@property (nonatomic, strong) NSNumber *corpId;
@property (nonatomic, strong) NSString *corpLogo;
@property (nonatomic, strong) NSString *corpName;
@property (nonatomic, strong) NSNumber *distance;
@property (nonatomic, strong) NSNumber *isFCode;
@property (nonatomic, strong) NSNumber *jobDate;
@property (nonatomic, strong) NSNumber *jobId;
@property (nonatomic, strong) NSString *jobName;
@property (nonatomic, strong) NSNumber *oddNum;
@property (nonatomic, strong) NSNumber *pay;
@property (nonatomic, strong) NSNumber *payunit;
@property (nonatomic, strong) NSNumber *redPaper;
@property (nonatomic, strong) NSNumber *regiEndTime;
@property (nonatomic, strong) NSNumber *regiStartTime;
@property (nonatomic, strong) NSNumber *status;

- (instancetype)initWithDic:(NSDictionary *)dic;

+ (SendModel *)sendModelWithDic:(NSDictionary *)dic;

@end
