//
//  HomeLatestModel.m
//  PartTime
//
//  Created by MS on 15-9-18.
//  Copyright (c) 2015年 jinrui. All rights reserved.
//

#import "HomeLatestModel.h"

@implementation HomeLatestModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    if ([key isEqualToString:@"id"]) {
        self.myId = value;
    }
}

- (id)valueForUndefinedKey:(NSString *)key {
    return nil;
}

- (instancetype)initWithDic:(NSDictionary *)dic {
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dic];
    }
    return self;
}

+ (HomeLatestModel *)homeLatesModelWithDic:(NSDictionary *)dic {
    HomeLatestModel *model = [[HomeLatestModel alloc] initWithDic:dic];
    return model;
}


@end
